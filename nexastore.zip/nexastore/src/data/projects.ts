import type { Project } from '@/types'

export const projectCategories = [
  { id: 'web', label: 'Web App' },
  { id: 'mobile', label: 'Mobile' },
  { id: 'ui', label: 'UI/UX' },
  { id: 'jaringan', label: 'Jaringan' },
] as const

export const projects: Project[] = [
  {
    id: 'p1',
    slug: 'nexastore-marketplace',
    title: 'NexaStore Marketplace',
    description: 'Platform marketplace produk digital dengan dashboard penjual, keranjang, dan sistem wishlist.',
    longDescription:
      'Dibangun dengan React, TypeScript, dan Tailwind CSS. Mencakup autentikasi peran (pembeli, penjual, admin), manajemen produk, dan alur checkout lengkap.',
    category: 'web',
    coverImage: 'https://images.unsplash.com/photo-1557821552-17105176677c?auto=format&fit=crop&w=800&q=80',
    tags: ['React', 'TypeScript', 'Tailwind CSS'],
    role: 'Full-Stack Developer',
    year: '2026',
    link: '',
    repo: '',
    featured: true,
  },
  {
    id: 'p2',
    slug: 'jaringan-sekolah',
    title: 'Perancangan Jaringan LAN Sekolah',
    description: 'Desain topologi dan konfigurasi jaringan LAN untuk laboratorium komputer sekolah.',
    longDescription:
      'Proyek TKJ mencakup perancangan topologi star, konfigurasi switch dan router, subnetting, serta dokumentasi pengkabelan.',
    category: 'jaringan',
    coverImage: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=800&q=80',
    tags: ['Cisco Packet Tracer', 'Subnetting', 'Mikrotik'],
    role: 'Network Engineer',
    year: '2025',
    featured: true,
  },
  {
    id: 'p3',
    slug: 'dashboard-admin',
    title: 'Dashboard Admin Analitik',
    description: 'Antarmuka dashboard untuk memvisualisasikan data penjualan dan aktivitas pengguna.',
    longDescription: 'Fokus pada tata letak data yang jelas, grafik interaktif, dan mode gelap.',
    category: 'ui',
    coverImage: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80',
    tags: ['Figma', 'Design System'],
    role: 'UI/UX Designer',
    year: '2025',
    featured: false,
  },
]

export function getProjectBySlug(slug: string): Project | undefined {
  return projects.find((p) => p.slug === slug)
}

export function getCategoryLabel(id: string): string {
  return projectCategories.find((c) => c.id === id)?.label ?? id
}
