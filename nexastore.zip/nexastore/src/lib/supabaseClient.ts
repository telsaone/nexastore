import { createClient, type SupabaseClient } from '@supabase/supabase-js'

/**
 * Client Supabase untuk fitur "Komentar Pengunjung" di halaman Hubungi Saya.
 * Kredensialnya diambil dari environment variable Vite (lihat .env.example) —
 * jangan taruh service_role key di sini, cukup URL project + anon public key
 * (keduanya memang didesain aman untuk dipakai di sisi browser/klien).
 *
 * Kalau belum diisi, `supabase` bernilai null dan komponen komentar akan
 * menampilkan pesan "belum dikonfigurasi" alih-alih error/crash.
 */

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined

export const isSupabaseConfigured = Boolean(supabaseUrl && supabaseAnonKey)

export const supabase: SupabaseClient | null = isSupabaseConfigured
  ? createClient(supabaseUrl as string, supabaseAnonKey as string)
  : null
