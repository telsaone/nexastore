export const STORAGE_KEYS = {
  profile: 'portfolio_profile',
} as const

export function readStorage<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(key)
    if (!raw) return fallback
    return JSON.parse(raw) as T
  } catch {
    return fallback
  }
}

export function writeStorage<T>(key: string, value: T): boolean {
  try {
    window.localStorage.setItem(key, JSON.stringify(value))
    return true
  } catch {
    // gagal — biasanya karena kuota localStorage penuh (foto profil terlalu besar)
    return false
  }
}
