import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function formatDate(iso: string): string {
  return new Intl.DateTimeFormat('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(new Date(iso))
}

export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs))
}

export function initials(name: string): string {
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase())
    .join('')
}

/**
 * formatRelativeTime — "2 menit lalu", "kemarin", dst. Dipakai di daftar komentar
 * pengunjung supaya terasa hidup (bukan cuma tanggal statis).
 */
export function formatRelativeTime(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime()
  const diffSec = Math.max(0, Math.round(diffMs / 1000))

  if (diffSec < 10) return 'baru saja'
  if (diffSec < 60) return `${diffSec} detik lalu`

  const diffMin = Math.round(diffSec / 60)
  if (diffMin < 60) return `${diffMin} menit lalu`

  const diffHour = Math.round(diffMin / 60)
  if (diffHour < 24) return `${diffHour} jam lalu`

  const diffDay = Math.round(diffHour / 24)
  if (diffDay === 1) return 'kemarin'
  if (diffDay < 7) return `${diffDay} hari lalu`

  return formatDate(iso)
}

// Palet gradient avatar untuk komentar — dipilih dari nama (hash sederhana) supaya
// tiap orang dapat warna yang konsisten setiap kali komentarnya tampil.
const AVATAR_GRADIENTS = [
  'from-gold to-violet',
  'from-violet to-gold-soft',
  'from-gold-deep to-violet-soft',
  'from-violet-deep to-gold',
  'from-gold-soft to-violet-deep',
] as const

export function avatarGradient(name: string): string {
  let hash = 0
  for (let i = 0; i < name.length; i++) {
    hash = (hash << 5) - hash + name.charCodeAt(i)
    hash |= 0
  }
  const index = Math.abs(hash) % AVATAR_GRADIENTS.length
  return AVATAR_GRADIENTS[index]
}

export function generateId(prefix: string): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`
}

export const MAX_PHOTO_SIZE_BYTES = 12 * 1024 * 1024 // 12 MB
export const ACCEPTED_PHOTO_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif']

export function formatBytes(bytes: number): string {
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}
