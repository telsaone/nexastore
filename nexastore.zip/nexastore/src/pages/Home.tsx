import { RobotScene } from '@/components/ui/robot-scene'
import LightRays from '@/components/reactbits/LightRays'

/**
 * Halaman Beranda didesain sebagai layar statis: tinggi persis 1 viewport
 * (dikurangi tinggi navbar 88px yang sudah dikompensasi lewat padding-top di
 * Layout), tanpa scroll — robot diletakkan di paling bawah, dan Footer sengaja
 * disembunyikan khusus di halaman ini (lihat Layout.tsx).
 */
export default function Home() {
  return (
    <div className="relative flex h-[calc(100dvh-88px)] w-full items-end justify-center overflow-hidden pb-8 md:pb-4">
      {/* Latar belakang animasi light rays — memenuhi SELURUH viewport (fixed, bukan
          absolute) supaya juga tampil persis di belakang navbar (yang di halaman ini
          dibuat transparan tanpa "kotak"/border/shadow lewat prop `transparent` di
          Navbar/CardNav), bukan cuma di area di bawah navbar. Tetap berada dalam
          stacking context <main> (z-10) sehingga tetap terlihat di belakang nav
          (z-50), dan pointer-events dimatikan supaya tidak menghalangi klik apa pun. */}
      <div className="pointer-events-none fixed inset-0 z-0">
        <LightRays
          raysOrigin="top-center"
          raysColor="#ffffff"
          raysSpeed={1.2}
          lightSpread={0.9}
          rayLength={1.6}
          fadeDistance={1.5}
          saturation={1}
          followMouse
          mouseInfluence={0.08}
          noiseAmount={0.05}
          distortion={0.03}
          className="h-full w-full"
        />
      </div>

      {/* Peredam lembut tepat di area siluet robot — supaya cahaya rays cuma
          "sedikit" menyentuh robot (tidak menyilaukan/menutupi bentuknya),
          sementara di sisi lain background rays tetap terlihat penuh. */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 bottom-0 z-[5] mx-auto h-[340px] w-[420px] sm:h-[400px] sm:w-[480px] lg:h-[480px] lg:w-[560px]"
        style={{
          background:
            'radial-gradient(closest-side, rgba(10,10,10,0.4), rgba(10,10,10,0.12) 55%, transparent 78%)',
        }}
      />

      <div className="relative z-10">
        <RobotScene />
      </div>
    </div>
  )
}
