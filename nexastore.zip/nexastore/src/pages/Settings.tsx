import { Moon, Sun } from 'lucide-react'
import FadeInSection from '@/components/reactbits/FadeInSection'
import SpotlightCard from '@/components/reactbits/SpotlightCard'
import { useTheme, type Theme } from '@/context/ThemeContext'
import { cn } from '@/lib/format'

const OPTIONS: Array<{ value: Theme; label: string; description: string; icon: typeof Sun }> = [
  { value: 'dark', label: 'Gelap', description: 'Latar gelap, nyaman di mata saat malam.', icon: Moon },
  { value: 'light', label: 'Terang', description: 'Latar terang, kontras tinggi di siang hari.', icon: Sun },
]

export default function Settings() {
  const { theme, setTheme } = useTheme()

  return (
    <div className="container-page pb-28 pt-6 md:pb-16">
      <FadeInSection>
        <div className="mb-8 max-w-xl">
          <h1 className="font-display text-2xl font-semibold text-ink sm:text-3xl">Pengaturan</h1>
          <p className="mt-2 text-sm text-ink-muted">Sesuaikan tampilan website sesuai kenyamanan kamu.</p>
        </div>
      </FadeInSection>

      <FadeInSection>
        <section className="max-w-xl">
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-ink-faint">
            Warna Tampilan
          </h2>
          <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
            {OPTIONS.map((option) => {
              const Icon = option.icon
              const active = theme === option.value
              return (
                <button key={option.value} type="button" onClick={() => setTheme(option.value)} className="text-left">
                  <SpotlightCard
                    className={cn(
                      'flex h-full flex-col gap-3 p-5 transition',
                      active ? 'border-gold/60 ring-1 ring-gold/40' : 'hover:border-gold/30',
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <span
                        className={cn(
                          'flex h-10 w-10 items-center justify-center rounded-full',
                          active ? 'bg-gold text-base' : 'bg-surface-hover text-ink-muted',
                        )}
                      >
                        <Icon size={18} />
                      </span>
                      {active && (
                        <span className="rounded-full bg-gold/15 px-2.5 py-1 text-[11px] font-semibold text-gold-soft">
                          Aktif
                        </span>
                      )}
                    </div>
                    <div>
                      <p className="font-semibold text-ink">{option.label}</p>
                      <p className="mt-1 text-xs text-ink-muted">{option.description}</p>
                    </div>
                  </SpotlightCard>
                </button>
              )
            })}
          </div>
          <p className="mt-4 text-xs text-ink-faint">
            Pilihan ini tersimpan otomatis di perangkat kamu dan berlaku lagi setiap kali membuka website ini.
          </p>
        </section>
      </FadeInSection>
    </div>
  )
}
