import { useState } from 'react'
import { Link } from 'react-router-dom'
import { GrainGradient } from '@paper-design/shaders-react'
import { Camera, LogOut, Settings, ShieldCheck } from 'lucide-react'
import ProfilePhotoUpload from '@/components/profile/ProfilePhotoUpload'
import FadeInSection from '@/components/reactbits/FadeInSection'
import { SocialButton } from '@/components/base/buttons/social-button'
import { useAuth } from '@/context/AuthContext'
import { isSupabaseConfigured } from '@/lib/supabaseClient'
import { useProfile } from '@/context/ProfileContext'
import { initials, cn } from '@/lib/format'

export default function About() {
  const { profile, updateProfile } = useProfile()
  const { user, isAdmin, signInWithProvider, signOut } = useAuth()
  const [isEditing, setIsEditing] = useState(false)
  const [draft, setDraft] = useState({ name: profile.name, role: profile.role })

  function startEdit() {
    setDraft({ name: profile.name, role: profile.role })
    setIsEditing(true)
  }

  function saveEdit() {
    updateProfile(draft)
    setIsEditing(false)
  }

  return (
    <div className="container-page pb-28 pt-6 md:pb-16">
      <FadeInSection>
        <div className="grid min-h-[560px] gap-6 lg:grid-cols-[0.94fr_1.06fr]">
          {/* Panel profil */}
          <div className="flex min-h-[420px] flex-col items-center justify-center gap-5 rounded-2xl border border-border-soft bg-surface px-6 py-12 sm:px-10 lg:min-h-0 lg:items-start lg:px-14">
            <ProfilePhotoUpload size="xl" />

            {!isEditing ? (
              <div className="flex flex-col items-center gap-1 lg:items-start">
                <h1 className="font-display text-2xl font-semibold text-ink sm:text-3xl">{profile.name}</h1>
                <p className="text-sm font-medium text-gold-soft">{profile.role}</p>
                <button
                  type="button"
                  onClick={startEdit}
                  className="mt-4 inline-flex items-center gap-1.5 rounded-xl border border-border px-3.5 py-2 text-xs font-medium text-ink-muted transition hover:border-gold/40 hover:text-ink"
                >
                  <Camera size={13} /> Edit
                </button>
              </div>
            ) : (
              <div className="flex w-full max-w-sm flex-col gap-3">
                <input
                  value={draft.name}
                  onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                  className="rounded-xl border border-border bg-surface px-4 py-2.5 text-sm text-ink outline-none focus:border-gold/50"
                />
                <input
                  value={draft.role}
                  onChange={(e) => setDraft({ ...draft, role: e.target.value })}
                  className="rounded-xl border border-border bg-surface px-4 py-2.5 text-sm text-ink outline-none focus:border-gold/50"
                />
                <div className="flex gap-2 pt-1">
                  <button
                    type="button"
                    onClick={saveEdit}
                    className="rounded-xl bg-gold px-4 py-2 text-xs font-semibold text-base"
                  >
                    Simpan
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsEditing(false)}
                    className="rounded-xl border border-border px-4 py-2 text-xs font-medium text-ink-muted"
                  >
                    Batal
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Panel animasi + menu akun */}
          <div className="relative flex min-h-[420px] overflow-hidden rounded-2xl bg-black p-8 text-white sm:p-12 lg:min-h-0">
            <GrainGradient
              speed={1}
              scale={1}
              rotation={0}
              offsetX={0}
              offsetY={0}
              softness={0.5}
              intensity={0.5}
              noise={0.25}
              shape="corners"
              frame={2854.5}
              colors={['#FFFFFF', '#FC7819', '#FC7819', '#FFFFFF']}
              colorBack="#00000000"
              className="absolute inset-0 bg-black"
            />

            <div className="relative z-10 flex h-full w-full flex-col justify-center gap-4">
              {!isSupabaseConfigured ? (
                <div className="rounded-xl border border-white/20 bg-black/30 px-5 py-4 text-xs text-white/70 backdrop-blur-sm">
                  Login belum dikonfigurasi. Isi VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY,
                  dan VITE_ADMIN_EMAIL.
                </div>
              ) : user ? (
                <div className="flex items-center gap-3 rounded-xl border border-white/20 bg-black/30 px-5 py-4 backdrop-blur-sm">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-gold to-violet text-sm font-semibold text-base">
                    {initials(user.email ?? '')}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-white">{user.email}</p>
                    {isAdmin && (
                      <p className="mt-0.5 inline-flex items-center gap-1 text-xs text-white/60">
                        <ShieldCheck size={12} /> Admin
                      </p>
                    )}
                  </div>
                  <button
                    onClick={signOut}
                    className="shrink-0 rounded-lg border border-white/25 p-2 text-white/70 transition hover:border-white/50 hover:text-white"
                  >
                    <LogOut size={14} />
                  </button>
                </div>
              ) : (
                <SocialButton
                  social="google"
                  theme="brand"
                  onClick={() => signInWithProvider('google')}
                />
              )}

              <Link
                to="/pengaturan"
                className={cn(
                  'inline-flex h-12 w-full items-center justify-center gap-2.5 rounded-[10px] border border-white/25 px-5 text-sm font-medium text-white/85 backdrop-blur-sm transition-colors hover:border-white/45 hover:text-white',
                )}
              >
                <Settings size={16} />
                Pengaturan Profil
              </Link>
            </div>
          </div>
        </div>
      </FadeInSection>
    </div>
  )
}
