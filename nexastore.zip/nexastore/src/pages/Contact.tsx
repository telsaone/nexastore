import { useState, type FormEvent } from 'react'
import { Mail, MapPin, Send, Twitter, Github, Instagram } from 'lucide-react'
import FadeInSection from '@/components/reactbits/FadeInSection'
import SpotlightCard from '@/components/reactbits/SpotlightCard'
import Button from '@/components/ui/Button'
import GuestComments from '@/components/comments/GuestComments'
import { useProfile } from '@/context/ProfileContext'
import { useToast } from '@/context/ToastContext'

export default function Contact() {
  const { profile } = useProfile()
  const { showToast } = useToast()
  const [form, setForm] = useState({ name: '', email: '', message: '' })

  function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!form.name || !form.email || !form.message) {
      showToast('Lengkapi semua kolom terlebih dahulu.', 'error')
      return
    }
    const subject = encodeURIComponent(`Pesan dari ${form.name} lewat Portfolio`)
    const body = encodeURIComponent(`${form.message}\n\n— ${form.name} (${form.email})`)
    window.location.href = `mailto:${profile.email}?subject=${subject}&body=${body}`
    showToast('Membuka aplikasi email kamu...', 'info')
  }

  return (
    <div className="container-page pb-28 pt-6 md:pb-16">
      <FadeInSection>
        <div className="mb-10 max-w-xl">
          <h1 className="font-display text-2xl font-semibold text-ink sm:text-3xl">Hubungi Saya</h1>
          <p className="mt-2 text-sm text-ink-muted">
            Ada proyek, kolaborasi, atau pertanyaan? Kirim pesan lewat form di bawah atau lewat kontak langsung.
          </p>
        </div>
      </FadeInSection>

      <div className="grid grid-cols-1 gap-8 md:grid-cols-[1fr_1.3fr]">
        <FadeInSection>
          <div className="flex flex-col gap-4">
            <SpotlightCard className="flex items-center gap-3 p-4">
              <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-surface-hover text-gold-soft">
                <Mail size={18} />
              </span>
              <div>
                <p className="text-xs text-ink-faint">Email</p>
                <p className="text-sm font-medium text-ink">{profile.email}</p>
              </div>
            </SpotlightCard>
            <SpotlightCard className="flex items-center gap-3 p-4">
              <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-surface-hover text-gold-soft">
                <MapPin size={18} />
              </span>
              <div>
                <p className="text-xs text-ink-faint">Lokasi</p>
                <p className="text-sm font-medium text-ink">{profile.location}</p>
              </div>
            </SpotlightCard>
            <div className="flex items-center gap-3 pt-2 text-ink-faint">
              {profile.social.twitter && (
                <a href={profile.social.twitter} target="_blank" rel="noreferrer" className="hover:text-ink">
                  <Twitter size={18} />
                </a>
              )}
              {profile.social.github && (
                <a href={profile.social.github} target="_blank" rel="noreferrer" className="hover:text-ink">
                  <Github size={18} />
                </a>
              )}
              {profile.social.instagram && (
                <a href={profile.social.instagram} target="_blank" rel="noreferrer" className="hover:text-ink">
                  <Instagram size={18} />
                </a>
              )}
            </div>
          </div>
        </FadeInSection>

        <FadeInSection>
          <form onSubmit={handleSubmit} className="flex flex-col gap-3">
            <input
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="Nama kamu"
              className="rounded-xl border border-border bg-surface px-4 py-2.5 text-sm text-ink outline-none focus:border-gold/50"
            />
            <input
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              placeholder="Email kamu"
              className="rounded-xl border border-border bg-surface px-4 py-2.5 text-sm text-ink outline-none focus:border-gold/50"
            />
            <textarea
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              placeholder="Pesan"
              rows={5}
              className="rounded-xl border border-border bg-surface px-4 py-2.5 text-sm text-ink outline-none focus:border-gold/50"
            />
            <Button type="submit" className="mt-1 self-start">
              <Send size={15} /> Kirim Pesan
            </Button>
          </form>
        </FadeInSection>
      </div>

      <GuestComments />
    </div>
  )
}
