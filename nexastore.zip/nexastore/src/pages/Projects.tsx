import { useMemo, useState } from 'react'
import { FolderKanban } from 'lucide-react'
import ProjectCard from '@/components/project/ProjectCard'
import PublicGallery from '@/components/gallery/PublicGallery'
import EmptyState from '@/components/ui/EmptyState'
import FadeInSection from '@/components/reactbits/FadeInSection'
import { projects, projectCategories } from '@/data/projects'
import { cn } from '@/lib/format'

export default function Projects() {
  const [activeCategory, setActiveCategory] = useState<string | null>(null)

  const filtered = useMemo(
    () => (activeCategory ? projects.filter((p) => p.category === activeCategory) : projects),
    [activeCategory],
  )

  return (
    <div className="container-page pb-28 pt-6 md:pb-16">
      <FadeInSection>
        <div className="mb-8">
          <h1 className="font-display text-2xl font-semibold text-ink sm:text-3xl">Karya & Proyek</h1>
          <p className="mt-2 max-w-xl text-sm text-ink-muted">
            Kumpulan proyek yang pernah saya kerjakan — dari pengembangan web hingga perancangan jaringan.
          </p>
        </div>

        <div className="mb-8 flex flex-wrap gap-2">
          <button
            onClick={() => setActiveCategory(null)}
            className={cn(
              'rounded-full border px-4 py-1.5 text-sm font-medium transition',
              activeCategory === null
                ? 'border-gold bg-gold/10 text-gold-soft'
                : 'border-border text-ink-muted hover:border-gold/40',
            )}
          >
            Semua
          </button>
          {projectCategories.map((c) => (
            <button
              key={c.id}
              onClick={() => setActiveCategory(c.id)}
              className={cn(
                'rounded-full border px-4 py-1.5 text-sm font-medium transition',
                activeCategory === c.id
                  ? 'border-gold bg-gold/10 text-gold-soft'
                  : 'border-border text-ink-muted hover:border-gold/40',
              )}
            >
              {c.label}
            </button>
          ))}
        </div>
      </FadeInSection>

      <FadeInSection>
        {filtered.length === 0 ? (
          <EmptyState icon={FolderKanban} title="Belum ada karya" description="Belum ada proyek pada kategori ini." />
        ) : (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((p) => (
              <ProjectCard key={p.id} project={p} />
            ))}
          </div>
        )}
      </FadeInSection>

      <PublicGallery />
    </div>
  )
}
