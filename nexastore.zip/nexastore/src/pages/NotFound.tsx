import { Link } from 'react-router-dom'
import { Compass } from 'lucide-react'
import Button from '@/components/ui/Button'

export default function NotFound() {
  return (
    <div className="container-page flex min-h-[70vh] flex-col items-center justify-center text-center">
      <div className="flex h-16 w-16 items-center justify-center rounded-full bg-surface-hover text-gold-soft">
        <Compass size={28} />
      </div>
      <h1 className="mt-6 font-display text-3xl font-semibold text-ink">Halaman tidak ditemukan</h1>
      <p className="mt-2 max-w-sm text-sm text-ink-muted">
        Halaman yang kamu cari tidak tersedia atau sudah dipindahkan.
      </p>
      <Link to="/" className="mt-6">
        <Button>Kembali ke Beranda</Button>
      </Link>
    </div>
  )
}
