import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'
import type { Session, User } from '@supabase/supabase-js'
import { supabase, isSupabaseConfigured } from '@/lib/supabaseClient'
import { useToast } from '@/context/ToastContext'

export type SocialProvider = 'google' | 'facebook' | 'apple'

/**
 * Email admin — cuma akun dengan email PERSIS SAMA dengan ini yang dianggap admin
 * setelah login. Diisi lewat VITE_ADMIN_EMAIL di .env (lihat LOGIN_GALERI_SETUP.md).
 * Perbandingannya case-insensitive supaya tidak salah gara-gara huruf besar/kecil.
 *
 * Catatan keamanan: pengecekan `isAdmin` di sini HANYA untuk menyembunyikan/menampilkan
 * fitur di UI (client-side). Perlindungan yang sesungguhnya tetap ada di RLS policy
 * tabel `gallery_images` di Supabase (lihat LOGIN_GALERI_SETUP.md) — jadi walau kode
 * front-end ini diubah/di-bypass, orang lain tetap tidak bisa insert ke tabelnya.
 */
const ADMIN_EMAIL = (import.meta.env.VITE_ADMIN_EMAIL as string | undefined)?.trim().toLowerCase()

interface AuthContextValue {
  user: User | null
  session: Session | null
  isLoading: boolean
  isAdmin: boolean
  signInWithProvider: (provider: SocialProvider) => Promise<void>
  signOut: () => Promise<void>
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const { showToast } = useToast()
  const [session, setSession] = useState<Session | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (!supabase) {
      setIsLoading(false)
      return
    }

    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session)
      setIsLoading(false)
    })

    const { data: listener } = supabase.auth.onAuthStateChange((_event, newSession) => {
      setSession(newSession)
    })

    return () => {
      listener.subscription.unsubscribe()
    }
  }, [])

  async function signInWithProvider(provider: SocialProvider) {
    if (!supabase) return
    const { error } = await supabase.auth.signInWithOAuth({
      provider,
      options: { redirectTo: window.location.href },
    })
    if (error) {
      showToast(`Gagal login dengan ${provider}. Coba lagi.`, 'error')
    }
    // Kalau sukses, browser akan di-redirect ke halaman login provider-nya,
    // jadi tidak perlu diapa-apakan lagi di sini.
  }

  async function signOut() {
    if (!supabase) return
    await supabase.auth.signOut()
    showToast('Berhasil keluar.', 'success')
  }

  const user = session?.user ?? null
  const isAdmin = Boolean(user?.email && ADMIN_EMAIL && user.email.toLowerCase() === ADMIN_EMAIL)

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        isLoading: isSupabaseConfigured ? isLoading : false,
        isAdmin,
        signInWithProvider,
        signOut,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
