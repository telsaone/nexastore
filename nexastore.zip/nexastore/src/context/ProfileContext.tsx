import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react'
import type { Profile } from '@/types'
import { STORAGE_KEYS, readStorage, writeStorage } from '@/lib/storage'
import { ACCEPTED_PHOTO_TYPES, MAX_PHOTO_SIZE_BYTES, formatBytes } from '@/lib/format'
import { useToast } from '@/context/ToastContext'

const DEFAULT_PROFILE: Profile = {
  name: 'Nama Kamu',
  role: 'Siswa TKJ · Web Developer',
  tagline: 'Merancang jaringan, membangun aplikasi.',
  bio: 'Siswa Teknik Komputer dan Jaringan yang senang membangun website dan mengonfigurasi jaringan. Halaman ini menampilkan karya dan proyek yang pernah saya kerjakan.',
  email: 'nama@email.com',
  location: 'Indonesia',
  photo: null,
  skills: ['HTML/CSS', 'JavaScript', 'React', 'Jaringan Komputer', 'Mikrotik', 'Cisco Packet Tracer'],
  social: {},
}

interface ProfileContextValue {
  profile: Profile
  updateProfile: (partial: Partial<Omit<Profile, 'social'>>) => void
  updateSocial: (partial: Partial<Profile['social']>) => void
  setPhotoFile: (file: File) => Promise<void>
  removePhoto: () => void
  isUploadingPhoto: boolean
}

const ProfileContext = createContext<ProfileContextValue | undefined>(undefined)

export function ProfileProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<Profile>(() => readStorage(STORAGE_KEYS.profile, DEFAULT_PROFILE))
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false)
  const { showToast } = useToast()

  useEffect(() => {
    writeStorage(STORAGE_KEYS.profile, profile)
  }, [profile])

  const updateProfile = useCallback((partial: Partial<Omit<Profile, 'social'>>) => {
    setProfile((prev) => ({ ...prev, ...partial }))
  }, [])

  const updateSocial = useCallback((partial: Partial<Profile['social']>) => {
    setProfile((prev) => ({ ...prev, social: { ...prev.social, ...partial } }))
  }, [])

  const setPhotoFile = useCallback(
    async (file: File) => {
      // Validasi format: jpg, jpeg, png, gif (gif tetap animasi karena disimpan apa adanya sebagai data URL)
      if (!ACCEPTED_PHOTO_TYPES.includes(file.type)) {
        showToast('Format foto tidak didukung. Gunakan JPG, JPEG, PNG, atau GIF.', 'error')
        return
      }
      if (file.size > MAX_PHOTO_SIZE_BYTES) {
        showToast(`Ukuran foto maksimal 12 MB (file kamu ${formatBytes(file.size)}).`, 'error')
        return
      }

      setIsUploadingPhoto(true)
      try {
        const dataUrl = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader()
          reader.onload = () => resolve(reader.result as string)
          reader.onerror = () => reject(new Error('Gagal membaca file'))
          reader.readAsDataURL(file)
        })

        setProfile((prev) => ({ ...prev, photo: dataUrl }))
        const saved = writeStorage(STORAGE_KEYS.profile, { ...profile, photo: dataUrl })
        if (saved) {
          showToast('Foto profil berhasil diperbarui.', 'success')
        } else {
          showToast('Foto ditampilkan, tapi terlalu besar untuk disimpan permanen di browser ini.', 'info')
        }
      } catch {
        showToast('Gagal mengunggah foto. Coba file lain.', 'error')
      } finally {
        setIsUploadingPhoto(false)
      }
    },
    [profile, showToast],
  )

  const removePhoto = useCallback(() => {
    setProfile((prev) => ({ ...prev, photo: null }))
  }, [])

  return (
    <ProfileContext.Provider
      value={{ profile, updateProfile, updateSocial, setPhotoFile, removePhoto, isUploadingPhoto }}
    >
      {children}
    </ProfileContext.Provider>
  )
}

export function useProfile(): ProfileContextValue {
  const ctx = useContext(ProfileContext)
  if (!ctx) throw new Error('useProfile must be used within ProfileProvider')
  return ctx
}
