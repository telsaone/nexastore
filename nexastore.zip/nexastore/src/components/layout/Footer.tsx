import { Link } from 'react-router-dom'
import { Hexagon, Twitter, Github, Instagram } from 'lucide-react'
import { useProfile } from '@/context/ProfileContext'

export default function Footer() {
  const { profile } = useProfile()

  return (
    <footer className="border-t border-border-soft bg-base-soft pb-24 md:pb-0">
      <div className="container-page grid grid-cols-2 gap-8 py-12 sm:grid-cols-4">
        <div className="col-span-2 sm:col-span-1">
          <Link to="/" className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-gold to-violet text-base">
              <Hexagon size={17} strokeWidth={2.5} className="fill-base/20" />
            </span>
            <span className="font-display text-lg font-semibold text-ink">{profile.name}</span>
          </Link>
          <p className="mt-3 max-w-xs text-sm text-ink-muted">{profile.tagline}</p>
          <div className="mt-4 flex items-center gap-3 text-ink-faint">
            {profile.social.twitter && (
              <a href={profile.social.twitter} target="_blank" rel="noreferrer" aria-label="Twitter" className="hover:text-ink">
                <Twitter size={17} />
              </a>
            )}
            {profile.social.github && (
              <a href={profile.social.github} target="_blank" rel="noreferrer" aria-label="GitHub" className="hover:text-ink">
                <Github size={17} />
              </a>
            )}
            {profile.social.instagram && (
              <a href={profile.social.instagram} target="_blank" rel="noreferrer" aria-label="Instagram" className="hover:text-ink">
                <Instagram size={17} />
              </a>
            )}
          </div>
        </div>

        <div>
          <h4 className="font-display text-sm font-semibold text-ink">Navigasi</h4>
          <ul className="mt-3 space-y-2">
            <li><Link to="/" className="text-sm text-ink-muted hover:text-gold-soft">Beranda</Link></li>
            <li><Link to="/karya" className="text-sm text-ink-muted hover:text-gold-soft">Karya & Proyek</Link></li>
            <li><Link to="/tentang" className="text-sm text-ink-muted hover:text-gold-soft">Tentang Saya</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-display text-sm font-semibold text-ink">Kontak</h4>
          <ul className="mt-3 space-y-2">
            <li><Link to="/kontak" className="text-sm text-ink-muted hover:text-gold-soft">Hubungi Saya</Link></li>
            <li><span className="text-sm text-ink-muted">{profile.email}</span></li>
            <li><span className="text-sm text-ink-muted">{profile.location}</span></li>
          </ul>
        </div>
      </div>

      <div className="border-t border-border-soft py-5">
        <p className="container-page text-center text-xs text-ink-faint">
          © {new Date().getFullYear()} {profile.name}. Website portofolio pribadi.
        </p>
      </div>
    </footer>
  )
}
