import { useLayoutEffect, useRef, useState, type KeyboardEvent } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { gsap } from 'gsap'
import { ArrowUpRight } from 'lucide-react'
import './CardNav.css'

export type CardNavLink = {
  label: string
  ariaLabel?: string
  /** Internal route — rendered with React Router's <Link> for client-side navigation. */
  to?: string
  /** External or non-router URL — rendered as a plain <a>. */
  href?: string
  /** Use for actions like "Keluar" (logout) instead of navigation. */
  onClick?: () => void
}

export type CardNavItem = {
  label: string
  bgColor: string
  textColor: string
  links: CardNavLink[]
}

export type CardNavProps = {
  logo: string
  logoAlt?: string
  items: CardNavItem[]
  className?: string
  ease?: string
  baseColor?: string
  menuColor?: string
  buttonBgColor?: string
  buttonTextColor?: string
  ctaLabel?: string
  ctaTo?: string
  onCtaClick?: () => void
  /** Saat true, hilangkan background/border/shadow/blur di bar nav (tanpa "kotak"),
   * dipakai di halaman Beranda supaya LightRays terlihat langsung di belakang nav. */
  transparent?: boolean
}

const CardNav = ({
  logo,
  logoAlt = 'Logo',
  items,
  className = '',
  ease = 'power3.out',
  baseColor = '#fff',
  menuColor,
  buttonBgColor,
  buttonTextColor,
  ctaLabel = 'Get Started',
  ctaTo,
  onCtaClick,
  transparent = false,
}: CardNavProps) => {
  const [isHamburgerOpen, setIsHamburgerOpen] = useState(false)
  const [isExpanded, setIsExpanded] = useState(false)
  const navRef = useRef<HTMLElement | null>(null)
  const cardsRef = useRef<HTMLDivElement[]>([])
  const tlRef = useRef<gsap.core.Timeline | null>(null)
  const { pathname } = useLocation()

  const calculateHeight = () => {
    const navEl = navRef.current
    if (!navEl) return 260

    const isMobile = window.matchMedia('(max-width: 768px)').matches
    if (isMobile) {
      const contentEl = navEl.querySelector<HTMLElement>('.card-nav-content')
      if (contentEl) {
        const wasVisible = contentEl.style.visibility
        const wasPointerEvents = contentEl.style.pointerEvents
        const wasPosition = contentEl.style.position
        const wasHeight = contentEl.style.height

        contentEl.style.visibility = 'visible'
        contentEl.style.pointerEvents = 'auto'
        contentEl.style.position = 'static'
        contentEl.style.height = 'auto'

        // Force reflow before reading scrollHeight
        void contentEl.offsetHeight

        const topBar = 60
        const padding = 16
        const contentHeight = contentEl.scrollHeight

        contentEl.style.visibility = wasVisible
        contentEl.style.pointerEvents = wasPointerEvents
        contentEl.style.position = wasPosition
        contentEl.style.height = wasHeight

        return topBar + contentHeight + padding
      }
    }
    return 260
  }

  const createTimeline = () => {
    const navEl = navRef.current
    if (!navEl) return null

    gsap.set(navEl, { height: 60, overflow: 'hidden' })
    gsap.set(cardsRef.current, { y: 50, opacity: 0 })

    const tl = gsap.timeline({ paused: true })

    tl.to(navEl, {
      height: calculateHeight,
      duration: 0.4,
      ease,
    })

    tl.to(cardsRef.current, { y: 0, opacity: 1, duration: 0.4, ease, stagger: 0.08 }, '-=0.1')

    return tl
  }

  useLayoutEffect(() => {
    const tl = createTimeline()
    if (tl && isExpanded) {
      // Menu sedang terbuka saat items berubah — langsung set ke posisi
      // terbuka juga, jangan biarkan mulai dari kolaps (state & visual jadi tidak sinkron).
      const newHeight = calculateHeight()
      gsap.set(navRef.current, { height: newHeight })
      tl.progress(1)
    }
    tlRef.current = tl

    return () => {
      tl?.kill()
      tlRef.current = null
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ease, items])

  // Tutup menu secara instan setiap kali berpindah halaman, sebagai jaring
  // pengaman — mencegah kartu menu "nyangkut" terbuka secara state namun
  // sudah tidak terlihat, yang membuat area link-nya jadi lapisan transparan
  // tak kasat mata yang menghalangi klik di halaman baru.
  const isFirstPathRender = useRef(true)
  useLayoutEffect(() => {
    if (isFirstPathRender.current) {
      isFirstPathRender.current = false
      return
    }
    setIsHamburgerOpen(false)
    setIsExpanded(false)
    tlRef.current?.kill()
    if (navRef.current) {
      gsap.set(navRef.current, { height: 60, overflow: 'hidden' })
    }
    gsap.set(cardsRef.current, { y: 50, opacity: 0 })
    tlRef.current = createTimeline()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname])

  useLayoutEffect(() => {
    let lastWidth = window.innerWidth

    const handleResize = () => {
      // Di Chrome mobile, scroll memicu address bar sembunyi/muncul yang
      // menembakkan event 'resize' berkali-kali walau lebar layar tidak
      // berubah. Abaikan supaya menu tidak dihitung ulang / glitch saat scroll.
      const currentWidth = window.innerWidth
      if (currentWidth === lastWidth) return
      lastWidth = currentWidth

      if (!tlRef.current) return

      if (isExpanded) {
        const newHeight = calculateHeight()
        gsap.set(navRef.current, { height: newHeight })

        tlRef.current.kill()
        const newTl = createTimeline()
        if (newTl) {
          newTl.progress(1)
          tlRef.current = newTl
        }
      } else {
        tlRef.current.kill()
        const newTl = createTimeline()
        if (newTl) {
          tlRef.current = newTl
        }
      }
    }

    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isExpanded])

  const toggleMenu = () => {
    const tl = tlRef.current
    if (!tl) return
    if (!isExpanded) {
      setIsHamburgerOpen(true)
      setIsExpanded(true)
      tl.play(0)
    } else {
      setIsHamburgerOpen(false)
      tl.eventCallback('onReverseComplete', () => setIsExpanded(false))
      tl.reverse()
    }
  }

  const closeMenu = () => {
    const tl = tlRef.current
    if (!tl || !isExpanded) return
    setIsHamburgerOpen(false)
    tl.eventCallback('onReverseComplete', () => setIsExpanded(false))
    tl.reverse()
  }

  const setCardRef = (i: number) => (el: HTMLDivElement | null) => {
    if (el) cardsRef.current[i] = el
  }

  function renderLink(lnk: CardNavLink, key: string) {
    if (lnk.onClick) {
      return (
        <button
          key={key}
          type="button"
          className="nav-card-link"
          aria-label={lnk.ariaLabel}
          onClick={() => {
            lnk.onClick?.()
            closeMenu()
          }}
        >
          <ArrowUpRight className="nav-card-link-icon" size={16} aria-hidden="true" />
          {lnk.label}
        </button>
      )
    }
    if (lnk.to) {
      return (
        <Link key={key} className="nav-card-link" to={lnk.to} aria-label={lnk.ariaLabel} onClick={closeMenu}>
          <ArrowUpRight className="nav-card-link-icon" size={16} aria-hidden="true" />
          {lnk.label}
        </Link>
      )
    }
    return (
      <a key={key} className="nav-card-link" href={lnk.href} aria-label={lnk.ariaLabel}>
        <ArrowUpRight className="nav-card-link-icon" size={16} aria-hidden="true" />
        {lnk.label}
      </a>
    )
  }

  return (
    <div className={`card-nav-container ${className}`}>
      <nav
        ref={navRef}
        className={`card-nav ${isExpanded ? 'open' : ''} ${transparent ? 'card-nav--transparent' : ''}`}
        style={transparent ? undefined : { backgroundColor: baseColor }}
      >
        <div className="card-nav-top">
          <div
            className={`hamburger-menu ${isHamburgerOpen ? 'open' : ''}`}
            onClick={toggleMenu}
            onKeyDown={(e: KeyboardEvent<HTMLDivElement>) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault()
                toggleMenu()
              }
            }}
            role="button"
            aria-label={isExpanded ? 'Tutup menu' : 'Buka menu'}
            aria-expanded={isExpanded}
            tabIndex={0}
            style={{ color: menuColor || '#000' }}
          >
            <div className="hamburger-line" />
            <div className="hamburger-line" />
          </div>

          <Link to="/" className="logo-container" onClick={closeMenu}>
            <img src={logo} alt={logoAlt} className="logo" />
            <span className="logo-wordmark" style={{ color: menuColor || '#000' }}>
              NexaStore
            </span>
          </Link>

          {ctaTo ? (
            <Link
              to={ctaTo}
              className="card-nav-cta-button"
              style={{ backgroundColor: buttonBgColor, color: buttonTextColor }}
              onClick={closeMenu}
            >
              {ctaLabel}
            </Link>
          ) : (
            <button
              type="button"
              className="card-nav-cta-button"
              style={{ backgroundColor: buttonBgColor, color: buttonTextColor }}
              onClick={onCtaClick}
            >
              {ctaLabel}
            </button>
          )}
        </div>

        <div className="card-nav-content" aria-hidden={!isExpanded}>
          {(items || []).slice(0, 3).map((item, idx) => (
            <div
              key={`${item.label}-${idx}`}
              className="nav-card"
              ref={setCardRef(idx)}
              style={{ backgroundColor: item.bgColor, color: item.textColor }}
            >
              <div className="nav-card-label">{item.label}</div>
              <div className="nav-card-links">
                {item.links?.map((lnk, i) => renderLink(lnk, `${lnk.label}-${i}`))}
              </div>
            </div>
          ))}
        </div>
      </nav>
    </div>
  )
}

export default CardNav
