import type { ReactNode } from 'react'
import { useLocation } from 'react-router-dom'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import PortfolioLimelightNav from '@/components/layout/PortfolioLimelightNav'

export default function Layout({ children }: { children: ReactNode }) {
  const { pathname } = useLocation()

  // Halaman Beranda didesain sebagai layar statis (robot + light rays), jadi Footer
  // disembunyikan khusus di halaman ini dan tinggi wrapper dikunci ke 1 viewport
  // (bukan min-h-screen) supaya tidak bisa di-scroll sama sekali.
  const isHome = pathname === '/'

  return (
    <div
      className={`relative flex flex-col bg-base ${
        isHome ? 'h-[100dvh] overflow-hidden' : 'min-h-screen'
      }`}
    >
      <Navbar transparent={isHome} />
      <main className="relative z-10 flex-1 pt-[88px]">{children}</main>
      {!isHome && <Footer />}
      <PortfolioLimelightNav />
    </div>
  )
}
