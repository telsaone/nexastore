import type { CSSProperties } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { Home, FolderKanban, UserRound, Mail, Settings } from 'lucide-react'
import { LimelightNav, type NavItem } from '@/components/ui/limelight-nav'

const ROUTES = ['/', '/karya', '/tentang', '/kontak', '/pengaturan']

// Variabel CSS yang dibutuhkan oleh limelight-nav.tsx (dipakai lewat var(--primary)
// pada shadow limelight-nya) — diset ke warna gold di proyek ini.
const primaryVarStyle = { '--primary': '#D9A441' } as CSSProperties

export default function PortfolioLimelightNav() {
  const navigate = useNavigate()
  const location = useLocation()

  const activeIndex = ROUTES.indexOf(location.pathname)
  // Sembunyikan di halaman yang tak dikenal (NotFound) agar tidak membingungkan
  if (activeIndex === -1) return null

  const items: NavItem[] = [
    { id: 'beranda', icon: <Home />, label: 'Beranda', onClick: () => navigate('/') },
    { id: 'karya', icon: <FolderKanban />, label: 'Karya', onClick: () => navigate('/karya') },
    { id: 'tentang', icon: <UserRound />, label: 'Tentang', onClick: () => navigate('/tentang') },
    { id: 'kontak', icon: <Mail />, label: 'Kontak', onClick: () => navigate('/kontak') },
    { id: 'pengaturan', icon: <Settings />, label: 'Pengaturan', onClick: () => navigate('/pengaturan') },
  ]

  return (
    <div
      className="pointer-events-none fixed inset-x-0 bottom-4 z-50 flex justify-center md:bottom-6"
      style={primaryVarStyle}
    >
      <div className="pointer-events-auto">
        {/* syncIndex menyinkronkan tab aktif dengan URL tanpa remount, supaya limelight-nya tetap
            meluncur ke kiri/kanan mengikuti klik user (bukan lompat langsung). */}
        <LimelightNav items={items} defaultActiveIndex={activeIndex} syncIndex={activeIndex} />
      </div>
    </div>
  )
}
