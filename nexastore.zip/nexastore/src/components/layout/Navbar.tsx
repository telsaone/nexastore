import { useMemo } from 'react'
import CardNav, { type CardNavItem } from '@/components/layout/CardNav'
import logo from '@/assets/nexastore-mark.svg'

export default function Navbar({ transparent = false }: { transparent?: boolean }) {
  const items: CardNavItem[] = useMemo(
    () => [
      {
        label: 'Jelajahi',
        bgColor: '#222222',
        textColor: '#EDEDED',
        links: [
          { label: 'Beranda', ariaLabel: 'Ke halaman Beranda', to: '/' },
          { label: 'Karya & Proyek', ariaLabel: 'Ke halaman Karya', to: '/karya' },
        ],
      },
      {
        label: 'Profil',
        bgColor: '#5B4FD1',
        textColor: '#FFFFFF',
        links: [{ label: 'Tentang Saya', ariaLabel: 'Ke halaman Tentang', to: '/tentang' }],
      },
      {
        label: 'Kontak',
        bgColor: '#B8842E',
        textColor: '#0A0A0A',
        links: [{ label: 'Hubungi Saya', ariaLabel: 'Ke halaman Kontak', to: '/kontak' }],
      },
    ],
    [],
  )

  return (
    <CardNav
      logo={logo}
      logoAlt="Portfolio"
      items={items}
      ease="power3.out"
      baseColor="rgba(255, 255, 255, 0.08)"
      menuColor="#EDEDED"
      buttonBgColor="#D9A441"
      buttonTextColor="#0A0A0A"
      ctaLabel="Kontak"
      ctaTo="/kontak"
      transparent={transparent}
    />
  )
}
