import type { ReactNode } from 'react'
import { cn } from '@/lib/format'

/**
 * GradientText — teks dengan gradasi warna gold → violet.
 * Terinspirasi dari komponen "Gradient Text" React Bits (https://reactbits.dev/).
 */
export function GradientText({ children, className }: { children: ReactNode; className?: string }) {
  return <span className={cn('text-gradient', className)}>{children}</span>
}

/**
 * ShinyButton — tombol dengan efek kilau (shine sweep) saat hover.
 * Terinspirasi dari komponen "Shiny Button" React Bits (https://reactbits.dev/).
 */
export function ShinyButtonWrap({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn('group/shiny relative isolate overflow-hidden rounded-xl', className)}>
      {children}
      <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/25 to-transparent transition-transform duration-700 group-hover/shiny:translate-x-full" />
    </div>
  )
}
