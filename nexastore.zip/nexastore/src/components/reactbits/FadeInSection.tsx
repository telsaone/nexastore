import { useEffect, useRef, useState, type ReactNode } from 'react'
import { cn } from '@/lib/format'

interface Props {
  children: ReactNode
  className?: string
  delay?: number
}

/**
 * FadeInSection — reveal fade + slide-up saat elemen pertama kali masuk viewport.
 * Terinspirasi dari komponen "Animated Content" React Bits (https://reactbits.dev/).
 */
export default function FadeInSection({ children, className, delay = 0 }: Props) {
  const ref = useRef<HTMLDivElement>(null)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true)
          observer.disconnect()
        }
      },
      { threshold: 0.15 },
    )
    observer.observe(el)
    return () => observer.disconnect()
  }, [])

  return (
    <div
      ref={ref}
      style={{ transitionDelay: `${delay}ms` }}
      className={cn(
        'transition-all duration-700 ease-out',
        visible ? 'translate-y-0 opacity-100' : 'translate-y-6 opacity-0',
        className,
      )}
    >
      {children}
    </div>
  )
}
