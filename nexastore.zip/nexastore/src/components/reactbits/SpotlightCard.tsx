import { useRef, type CSSProperties, type MouseEvent, type ReactNode } from 'react'
import { cn } from '@/lib/format'

interface Props {
  children: ReactNode
  className?: string
  spotlightColor?: string
}

/**
 * SpotlightCard — kartu dengan efek cahaya radial yang mengikuti posisi kursor.
 * Terinspirasi dari pola "Spotlight Card" React Bits (https://reactbits.dev/).
 */
export default function SpotlightCard({
  children,
  className,
  spotlightColor = 'rgba(217, 164, 65, 0.16)',
}: Props) {
  const ref = useRef<HTMLDivElement>(null)

  function handleMouseMove(e: MouseEvent<HTMLDivElement>) {
    const el = ref.current
    if (!el) return
    const rect = el.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top
    el.style.setProperty('--spot-x', `${x}px`)
    el.style.setProperty('--spot-y', `${y}px`)
  }

  return (
    <div
      ref={ref}
      onMouseMove={handleMouseMove}
      style={{ '--spot-color': spotlightColor } as CSSProperties}
      className={cn(
        'group/spot relative overflow-hidden rounded-2xl border border-border-soft bg-surface transition-colors duration-300 hover:border-gold/30',
        className,
      )}
    >
      <div
        className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 group-hover/spot:opacity-100"
        style={{
          background:
            'radial-gradient(400px circle at var(--spot-x, 50%) var(--spot-y, 50%), var(--spot-color), transparent 70%)',
        }}
      />
      <div className="relative">{children}</div>
    </div>
  )
}
