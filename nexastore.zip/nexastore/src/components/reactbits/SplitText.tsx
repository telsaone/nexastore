import { cn } from '@/lib/format'

interface Props {
  text: string
  className?: string
  delayStep?: number
  as?: 'h1' | 'h2' | 'p' | 'span'
}

/**
 * SplitText — animasi reveal kata per kata pada satu momen load halaman.
 * Terinspirasi dari komponen "Split Text" React Bits (https://reactbits.dev/).
 */
export default function SplitText({ text, className, delayStep = 60, as = 'span' }: Props) {
  const words = text.split(' ')
  const Tag = as

  return (
    <Tag className={cn('inline-flex flex-wrap', className)}>
      {words.map((word, i) => (
        <span key={i} className="mr-[0.28em] overflow-hidden">
          <span
            className="inline-block animate-fadeUp"
            style={{ animationDelay: `${i * delayStep}ms`, animationFillMode: 'both' }}
          >
            {word}
          </span>
        </span>
      ))}
    </Tag>
  )
}
