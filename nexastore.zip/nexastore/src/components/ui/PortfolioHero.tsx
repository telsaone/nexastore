import { motion } from 'motion/react'
import { Link } from 'react-router-dom'
import { useProfile } from '@/context/ProfileContext'
import { projects } from '@/data/projects'
import { initials } from '@/lib/format'
import ProfilePhotoUpload from '@/components/profile/ProfilePhotoUpload'

// --- Aksen SVG gambar tangan ---

const ArrowGreenLeft = () => (
  <svg viewBox="0 0 100 100" className="w-full h-full text-[#CCFF00] stroke-current overflow-visible" fill="none" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round">
    <path d="M10,90 C 10,40 40,20 60,50 C 70,65 80,75 95,70" />
    <path d="M80,55 L95,70 L85,85" />
  </svg>
)

const ArrowGreenRight = () => (
  <svg viewBox="0 0 100 100" className="w-full h-full text-[#CCFF00] stroke-current overflow-visible" fill="none" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round">
    <path d="M90,10 C 80,60 60,80 40,60 C 20,40 40,20 60,30 C 80,40 70,70 50,80" />
    <path d="M65,75 L50,80 L55,65" />
  </svg>
)

const CircularBadge = () => (
  <div className="relative bg-[#CCFF00] rounded-full flex items-center justify-center shadow-xl rotate-12 hover:scale-105 transition-transform cursor-pointer border-[3px] border-black/5 w-24 h-24 md:w-28 md:h-28">
    <div className="absolute inset-1 animate-[spin_10s_linear_infinite]">
      <svg viewBox="0 0 100 100" className="w-full h-full">
        <path id="portfolioCirclePath" d="M 50, 50 m -36, 0 a 36,36 0 1,1 72,0 a 36,36 0 1,1 -72,0" fill="none" />
        <text className="text-[9px] font-black tracking-[0.15em] uppercase" fill="black">
          <textPath href="#portfolioCirclePath" startOffset="0%">
            LIHAT KARYA SAYA • LIHAT KARYA SAYA •
          </textPath>
        </text>
      </svg>
    </div>
    <div className="absolute inset-0 flex items-center justify-center">
      <svg viewBox="0 0 100 100" className="text-black stroke-current overflow-visible w-8 h-8" fill="none" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round">
        <path d="M20,80 Q 40,50 30,30 T 80,20" />
        <path d="M60,10 L80,20 L70,40" />
      </svg>
    </div>
  </div>
)

/**
 * PortfolioHero — banner sapaan portofolio. Diadaptasi dari komponen hero
 * animasi "Rewards Club" (tipografi raksasa, kartu melayang, badge berputar),
 * dibuat lebih besar & lebih tinggi ke bawah, dan foto profil di kartu kiri
 * memakai foto yang bisa diunggah pengguna (JPG/PNG/GIF, GIF tetap bergerak).
 */
export default function PortfolioHero() {
  const { profile } = useProfile()
  const projectCount = projects.length

  return (
    <div className="relative w-full overflow-hidden rounded-[2rem] bg-[#0038FF] font-sans selection:bg-[#CCFF00] selection:text-black">
      {/* Grid latar belakang */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff15_1px,transparent_1px),linear-gradient(to_bottom,#ffffff15_1px,transparent_1px)] bg-[size:4rem_4rem] pointer-events-none z-0"></div>

      {/* Bar label mini */}
      <div className="relative z-20 flex items-center justify-between max-w-[1440px] mx-auto w-full px-5 py-4 md:px-8 md:py-6">
        <div className="flex items-center gap-1">
          <div className="bg-white text-black font-black tracking-tight text-xs md:text-sm px-3 py-1.5 rounded-2xl rounded-bl-sm relative shadow-sm">
            {initials(profile.name) || 'ME'}
            <div className="absolute -bottom-1.5 left-0 w-3 h-3 bg-white" style={{ clipPath: 'polygon(0 0, 100% 0, 0 100%)' }}></div>
          </div>
          <div className="bg-[#CCFF00] text-black font-black text-xs md:text-sm px-3 py-1.5 rounded-full border-[1.5px] border-white shadow-sm">
            PORTOFOLIO
          </div>
        </div>

        <div className="hidden md:flex items-center space-x-2">
          {[
            { label: 'Tentang', to: '/tentang' },
            { label: 'Karya', to: '/karya' },
            { label: 'Kontak', to: '/kontak' },
          ].map((item) => (
            <Link key={item.label} to={item.to} className="px-4 py-1.5 rounded-full border border-white/30 text-white text-xs font-semibold hover:bg-white/10 transition-colors">
              {item.label}
            </Link>
          ))}
        </div>

        <Link
          to="/kontak"
          className="px-6 py-2 rounded-full border border-white text-white text-xs md:text-sm font-semibold hover:bg-white hover:text-[#0038FF] transition-colors"
        >
          Hubungi Saya
        </Link>
      </div>

      {/* Bagian hero */}
      <main className="relative z-10 px-4 flex flex-col items-center justify-center w-full max-w-[1440px] mx-auto pt-6 pb-32 md:pt-10 md:pb-48">
        <div className="relative w-full max-w-5xl mx-auto flex flex-col items-center justify-center text-center z-10 mt-3 mb-10 md:mb-16">
          {/* Tumpukan teks */}
          <div className="w-full flex flex-col items-center relative z-10 space-y-1 md:space-y-2">
            {/* #KARYA */}
            <div className="w-full flex justify-start pl-[6%] md:pl-[20%] relative z-30">
              <h1
                className="font-black leading-[0.85] tracking-tighter text-[#CCFF00] m-0 p-0 uppercase text-[clamp(1.9rem,7vw,84px)]"
                style={{
                  fontFamily: '"Arial Black", Impact, sans-serif',
                  textShadow: '1px 1px 0 #001A99, 2px 2px 0 #001A99, 3px 3px 0 #001A99, 4px 4px 0 #001A99',
                }}
              >
                #KARYA
              </h1>
            </div>

            {/* PORTOFOLIO */}
            <div className="w-full flex justify-center relative z-20">
              <h1
                className="font-black leading-[0.85] tracking-tighter text-white m-0 p-0 uppercase text-[clamp(2.2rem,8vw,104px)]"
                style={{
                  fontFamily: '"Arial Black", Impact, sans-serif',
                  textShadow: '1px 1px 0 #001A99, 2px 2px 0 #001A99, 3px 3px 0 #001A99, 4px 4px 0 #001A99',
                }}
              >
                PORTOFOLIO
              </h1>
            </div>

            {/* KREATOR */}
            <div className="w-full flex justify-start pl-[12%] md:pl-[26%] relative z-10">
              <h1
                className="font-black leading-[0.85] tracking-tighter text-white m-0 p-0 uppercase text-[clamp(1.9rem,7vw,84px)]"
                style={{
                  fontFamily: '"Arial Black", Impact, sans-serif',
                  textShadow: '1px 1px 0 #001A99, 2px 2px 0 #001A99, 3px 3px 0 #001A99, 4px 4px 0 #001A99',
                }}
              >
                KREATOR
              </h1>
            </div>
          </div>

          {/* Overlay absolut (kartu, panah, badge) */}
          <div className="absolute inset-0 w-full h-full pointer-events-none">
            {/* Kartu kaca melayang 1 (kiri bawah) — foto profil */}
            <motion.div
              animate={{ y: [0, -15, 0] }}
              transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
              className="absolute bottom-[6%] left-[3%] md:left-[16%] z-30 pointer-events-auto"
            >
              <div className="aspect-[3/3.5] bg-white/20 backdrop-blur-md border border-white/40 rounded-[2rem] flex flex-col items-center justify-center rotate-[-12deg] shadow-2xl hover:rotate-0 transition-transform duration-500 w-28 md:w-36 p-3">
                <ProfilePhotoUpload size="sm" editable={false} className="mb-3" />
                <div className="text-center mt-1">
                  <p className="font-bold text-white text-xs md:text-sm">{profile.name}</p>
                  <p className="text-white/80 mt-1 text-[10px] md:text-xs">{profile.role}</p>
                </div>
              </div>
            </motion.div>

            {/* Kartu kaca melayang 2 (kanan atas) — statistik karya */}
            <motion.div
              animate={{ y: [0, -20, 0] }}
              transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
              className="absolute top-[8%] right-[3%] md:right-[18%] z-30 pointer-events-auto"
            >
              <div className="aspect-[3/3.5] bg-white/20 backdrop-blur-md border border-white/40 rounded-[2rem] flex flex-col items-center justify-center rotate-[12deg] shadow-2xl hover:rotate-0 transition-transform duration-500 w-28 md:w-36 p-3">
                <div className="bg-[#CCFF00] rounded-full flex items-center justify-center mb-3 shadow-inner border-[3px] border-white/50 w-10 h-10 md:w-14 md:h-14">
                  <span className="font-black text-black text-sm md:text-base">{projectCount}+</span>
                </div>
                <div className="text-center mt-1">
                  <p className="font-bold text-white text-xs md:text-sm">Proyek</p>
                  <p className="text-white/80 mt-1 text-[10px] md:text-xs">Siap Dilihat</p>
                </div>
              </div>
            </motion.div>

            {/* Panah dekoratif */}
            <div className="absolute bottom-[0%] left-[0%] md:left-[8%] z-20 w-14 h-14 md:w-20 md:h-20">
              <ArrowGreenLeft />
            </div>
            <div className="absolute top-[2%] right-[0%] md:right-[8%] z-20 w-14 h-14 md:w-20 md:h-20">
              <ArrowGreenRight />
            </div>

            {/* Badge berputar — digeser lebih ke bawah supaya tidak menutupi elemen lain */}
            <div className="absolute bottom-[-20%] right-[2%] md:right-[14%] z-40 pointer-events-auto">
              <Link to="/karya">
                <CircularBadge />
              </Link>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
