import { useEffect, useRef, useState } from 'react'
import { SplineScene } from '@/components/ui/spline'

/**
 * RobotScene — scene 3D robot, dibuat kecil dan diletakkan agak ke bawah
 * (bukan mepet ke atas), tanpa box/border, langsung menyatu dengan latar
 * belakang halaman (yang sudah hitam doff secara global).
 *
 * Dua tambahan di file ini:
 *
 * 1) Lazy-mount (ringan): scene 3D (Spline + WebGL) baru benar-benar dibuat saat
 *    komponen ini terlihat di viewport (IntersectionObserver), bukan langsung saat
 *    halaman dibuka. Ini mengurangi beban GPU/network di awal load.
 *
 * 2) "Look at cursor": robot mengikuti posisi mouse/jari secara TERUS-MENERUS
 *    di MANA SAJA di halaman (termasuk ikon-ikon di navbar atas & bottom nav),
 *    bukan cuma saat hover tepat di atas scene-nya, dan bukan cuma saat
 *    diklik/ditap — jadi robot langsung "hidup" mengikuti kursor begitu halaman
 *    dibuka, tanpa harus menyentuh robotnya dulu.
 *
 *    Caranya: setiap kali ada pointermove/touchmove asli di window, kita kirim
 *    event pointer/mouse tiruan (posisinya = posisi kursor/jari saat ini) ke
 *    window. Scene Spline ini didesain untuk mengikuti posisi kursor secara
 *    global (bukan cuma saat hover di atas canvas-nya), jadi ia akan bereaksi
 *    terhadap event tiruan ini sama seperti gerakan mouse asli. Event tiruan ini
 *    ditandai `isTrusted: false` oleh browser secara otomatis, jadi tidak akan
 *    memicu handler pointermove kita sendiri lagi (tidak ada loop).
 *
 *    Catatan: perilaku persis "menoleh mengikuti kursor" bergantung pada
 *    bagaimana interaksi look-at ini dirancang di dalam file scene Spline-nya
 *    sendiri (di luar kendali kode React ini). Kalau setelah `npm install`
 *    hasilnya belum pas, titik yang paling mudah disesuaikan adalah dua baris
 *    `window.dispatchEvent(...)` di fungsi `lookAt` di bawah ini.
 */
export function RobotScene() {
  const wrapperRef = useRef<HTMLDivElement | null>(null)
  const [shouldMount, setShouldMount] = useState(false)

  // (1) Lazy-mount saat masuk viewport
  useEffect(() => {
    const el = wrapperRef.current
    if (!el) return

    const observer = new IntersectionObserver(
      entries => {
        if (entries[0]?.isIntersecting) {
          setShouldMount(true)
          observer.disconnect()
        }
      },
      { threshold: 0.15 },
    )

    observer.observe(el)
    return () => observer.disconnect()
  }, [])

  // (2) Robot mengikuti posisi mouse/sentuhan secara TERUS-MENERUS di mana saja
  // di halaman (bukan cuma saat klik/tap, dan bukan cuma saat hover tepat di
  // atas scene-nya) — jadi robot sudah "hidup" mengikuti kursor begitu halaman
  // dibuka, tanpa perlu menyentuh robotnya dulu.
  useEffect(() => {
    const lookAt = (clientX: number, clientY: number) => {
      const opts = { clientX, clientY, bubbles: true, cancelable: true }
      // Dua tipe event dikirim sekaligus supaya kompatibel dengan cara mana pun
      // scene Spline ini "mendengarkan" posisi kursor (pointer atau mouse).
      window.dispatchEvent(new PointerEvent('pointermove', opts))
      window.dispatchEvent(new MouseEvent('mousemove', opts))
    }

    // Guard `isTrusted`: event yang kita dispatch sendiri di atas (pointermove/
    // mousemove tiruan) TIDAK trusted, jadi tidak akan memicu handler ini lagi
    // secara berulang (mencegah loop tak berujung), sementara gerakan mouse asli
    // pengguna tetap ditangkap dan diteruskan terus-menerus.
    const handlePointerMove = (e: PointerEvent) => {
      if (!e.isTrusted) return
      lookAt(e.clientX, e.clientY)
    }

    const handleTouchStart = (e: TouchEvent) => {
      const touch = e.touches[0]
      if (touch) lookAt(touch.clientX, touch.clientY)
    }

    // touchmove menangani gerakan jari saat drag di perangkat sentuh (setara
    // dengan pointermove untuk mouse), supaya robot tetap mengikuti selama jari
    // bergerak, bukan cuma di titik sentuh pertama.
    const handleTouchMove = (e: TouchEvent) => {
      const touch = e.touches[0]
      if (touch) lookAt(touch.clientX, touch.clientY)
    }

    window.addEventListener('pointermove', handlePointerMove)
    window.addEventListener('touchstart', handleTouchStart, { passive: true })
    window.addEventListener('touchmove', handleTouchMove, { passive: true })

    return () => {
      window.removeEventListener('pointermove', handlePointerMove)
      window.removeEventListener('touchstart', handleTouchStart)
      window.removeEventListener('touchmove', handleTouchMove)
    }
  }, [])

  return (
    <div
      ref={wrapperRef}
      className="flex h-[56vh] min-h-[280px] max-h-[420px] w-full max-w-lg items-end justify-center sm:max-h-[480px] lg:max-h-[560px] lg:max-w-xl"
    >
      <div className="h-full max-h-full w-full overflow-hidden">
        {shouldMount && (
          <SplineScene
            scene="https://prod.spline.design/kZDDjO5HuC9GJUM2/scene.splinecode"
            className="h-full w-full"
          />
        )}
      </div>
    </div>
  )
}
