import type { ReactNode } from 'react'
import { cn } from '@/lib/format'

type Tone = 'gold' | 'violet' | 'neutral' | 'success' | 'danger'

const toneClasses: Record<Tone, string> = {
  gold: 'bg-gold/10 text-gold border-gold/25',
  violet: 'bg-violet/10 text-violet-soft border-violet/25',
  neutral: 'bg-surface-hover text-ink-muted border-border',
  success: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/25',
  danger: 'bg-red-500/10 text-red-400 border-red-500/25',
}

export default function Badge({
  children,
  tone = 'neutral',
  className,
}: {
  children: ReactNode
  tone?: Tone
  className?: string
}) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-xs font-medium',
        toneClasses[tone],
        className,
      )}
    >
      {children}
    </span>
  )
}
