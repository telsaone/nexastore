import React, { useState, useRef, useLayoutEffect, cloneElement } from 'react';

// --- Internal Types and Defaults ---

const DefaultHomeIcon = (props: React.SVGProps<SVGSVGElement>) => <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" /></svg>;
const DefaultCompassIcon = (props: React.SVGProps<SVGSVGElement>) => <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><path d="m16.24 7.76-2.12 6.36-6.36 2.12 2.12-6.36 6.36-2.12z" /></svg>;
const DefaultBellIcon = (props: React.SVGProps<SVGSVGElement>) => <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" /><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" /></svg>;

export type NavItem = {
  id: string | number;
  icon: React.ReactElement;
  label?: string;
  onClick?: () => void;
};

const defaultNavItems: NavItem[] = [
  { id: 'default-home', icon: <DefaultHomeIcon />, label: 'Home' },
  { id: 'default-explore', icon: <DefaultCompassIcon />, label: 'Explore' },
  { id: 'default-notifications', icon: <DefaultBellIcon />, label: 'Notifications' },
];

type LimelightNavProps = {
  items?: NavItem[];
  defaultActiveIndex?: number;
  /**
   * (Tambahan integrasi, bukan bagian dari komponen asli) — index aktif yang disinkronkan dari
   * luar (mis. saat pindah halaman lewat navbar atas, bukan lewat klik di komponen ini sendiri).
   * Diterapkan lewat state internal yang sama seperti klik, jadi limelight tetap meluncur
   * (bukan lompat) — remount TIDAK dipakai di sini supaya animasi geser kiri/kanannya utuh.
   */
  syncIndex?: number;
  onTabChange?: (index: number) => void;
  className?: string;
  limelightClassName?: string;
  iconContainerClassName?: string;
  iconClassName?: string;
};

/**
 * An adaptive-width navigation bar with a "limelight" effect that highlights the active item.
 *
 * Catatan integrasi: file ini adalah komponen "limelight-nav" apa adanya — logika, state,
 * ref, useLayoutEffect, dan prop API-nya tidak diubah sama sekali dari sumber aslinya.
 * Satu-satunya perubahan adalah nama kelas warna: proyek ini tidak memakai variabel CSS
 * shadcn/ui (bg-card, text-foreground, bg-primary, dst juga tidak terdaftar di tema Tailwind
 * proyek ini), jadi kelas tersebut diganti ke token desain proyek yang sepadan
 * (bg-card→bg-surface-raised, text-foreground→text-ink, border→border-border, bg-primary→bg-gold).
 * `var(--primary)` tetap dipakai apa adanya dan disuplai lewat inline style di pemanggilnya.
 * Satu penambahan kecil: prop `syncIndex` (lihat komentar di atas) supaya nav ini bisa disinkronkan
 * dari luar tanpa remount, karena remount akan membatalkan animasi geser limelight-nya.
 * Penyesuaian lain: durasi & easing transisi geser limelight (saat pindah tab lewat klik)
 * diperlambat dan dihaluskan (420ms ease-in-out → 650ms cubic-bezier ease-out) supaya
 * perpindahannya terasa lebih smooth, tidak terlalu cepat/tersentak; fade opacity ikon
 * ikut sedikit diperlambat (100ms → 300ms) biar selaras dengan geseran limelight-nya.
 */
export const LimelightNav = ({
  items = defaultNavItems,
  defaultActiveIndex = 0,
  syncIndex,
  onTabChange,
  className,
  limelightClassName,
  iconContainerClassName,
  iconClassName,
}: LimelightNavProps) => {
  const [activeIndex, setActiveIndex] = useState(defaultActiveIndex);
  const [isReady, setIsReady] = useState(false);
  const navItemRefs = useRef<(HTMLAnchorElement | null)[]>([]);
  const limelightRef = useRef<HTMLDivElement | null>(null);

  useLayoutEffect(() => {
    if (typeof syncIndex === 'number' && syncIndex !== activeIndex) {
      setActiveIndex(syncIndex);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [syncIndex]);

  useLayoutEffect(() => {
    if (items.length === 0) return;

    const limelight = limelightRef.current;
    const activeItem = navItemRefs.current[activeIndex];

    if (limelight && activeItem) {
      const newLeft = activeItem.offsetLeft + activeItem.offsetWidth / 2 - limelight.offsetWidth / 2;
      limelight.style.left = `${newLeft}px`;

      if (!isReady) {
        setTimeout(() => setIsReady(true), 50);
      }
    }
  }, [activeIndex, isReady, items]);

  if (items.length === 0) {
    return null;
  }

  const handleItemClick = (index: number, itemOnClick?: () => void) => {
    setActiveIndex(index);
    onTabChange?.(index);
    itemOnClick?.();
  };

  return (
    <nav className={`relative inline-flex items-center h-16 rounded-lg bg-surface-raised text-ink border border-border px-2 ${className}`}>
      {items.map(({ id, icon, label, onClick }, index) => (
          <a
            key={id}
            ref={el => (navItemRefs.current[index] = el)}
            className={`relative z-20 flex h-full cursor-pointer items-center justify-center p-5 ${iconContainerClassName}`}
            onClick={() => handleItemClick(index, onClick)}
            aria-label={label}
          >
            {cloneElement(icon, {
              className: `w-6 h-6 transition-opacity duration-300 ease-in-out ${
                activeIndex === index ? 'opacity-100' : 'opacity-40'
              } ${icon.props.className || ''} ${iconClassName || ''}`,
            })}
          </a>
      ))}

      <div
        ref={limelightRef}
        className={`absolute top-0 z-10 w-11 h-[5px] rounded-full bg-gold shadow-[0_50px_15px_var(--primary)] ${
          isReady ? 'transition-[left] duration-[650ms] ease-[cubic-bezier(0.22,1,0.36,1)]' : ''
        } ${limelightClassName}`}
        style={{ left: '-999px' }}
      >
        <div className="absolute left-[-30%] top-[5px] w-[160%] h-14 [clip-path:polygon(5%_100%,25%_0,75%_0,95%_100%)] bg-gradient-to-b from-gold/30 to-transparent pointer-events-none" />
      </div>
    </nav>
  );
};
