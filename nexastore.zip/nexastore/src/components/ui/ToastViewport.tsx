import { CheckCircle2, XCircle, Info, X } from 'lucide-react'
import type { ToastMessage } from '@/types'
import { cn } from '@/lib/format'

interface Props {
  toasts: ToastMessage[]
  onDismiss: (id: string) => void
}

const iconMap = {
  success: CheckCircle2,
  error: XCircle,
  info: Info,
}

const accentMap = {
  success: 'border-emerald-500/30 text-emerald-400',
  error: 'border-red-500/30 text-red-400',
  info: 'border-violet-500/30 text-violet-300',
}

export default function ToastViewport({ toasts, onDismiss }: Props) {
  if (toasts.length === 0) return null

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-0 z-[100] flex flex-col items-center gap-2 p-4 sm:items-end sm:bottom-6 sm:right-6 sm:inset-x-auto">
      {toasts.map((toast) => {
        const Icon = iconMap[toast.type]
        return (
          <div
            key={toast.id}
            role="status"
            className={cn(
              'pointer-events-auto flex w-full max-w-sm animate-fadeUp items-start gap-3 rounded-xl border bg-surface-raised/95 px-4 py-3 shadow-lg backdrop-blur',
              accentMap[toast.type],
            )}
          >
            <Icon size={18} className="mt-0.5 shrink-0" />
            <p className="flex-1 text-sm text-ink">{toast.message}</p>
            <button
              onClick={() => onDismiss(toast.id)}
              className="shrink-0 text-ink-faint transition hover:text-ink"
              aria-label="Tutup notifikasi"
            >
              <X size={16} />
            </button>
          </div>
        )
      })}
    </div>
  )
}
