import { LogOut, ShieldCheck, Sparkles, UserRound } from 'lucide-react'
import { SocialButton } from '@/components/base/buttons/social-button'
import SpotlightCard from '@/components/reactbits/SpotlightCard'
import { useAuth, type SocialProvider } from '@/context/AuthContext'
import { isSupabaseConfigured } from '@/lib/supabaseClient'
import { initials } from '@/lib/format'

const PROVIDERS: SocialProvider[] = ['google', 'facebook', 'apple']

/**
 * LoginPanel — kartu login di halaman Tentang. Siapa saja boleh login (Google/
 * Facebook/Apple), tapi hanya akun dengan email yang cocok dengan VITE_ADMIN_EMAIL
 * yang dianggap admin (lihat AuthContext & LOGIN_GALERI_SETUP.md). Status admin ini
 * yang dipakai PublicGallery untuk menampilkan/menyembunyikan fitur tambah gambar.
 */
export default function LoginPanel() {
  const { user, isLoading, isAdmin, signInWithProvider, signOut } = useAuth()

  if (!isSupabaseConfigured) {
    return (
      <SpotlightCard className="p-6 text-center">
        <Sparkles className="mx-auto mb-2 text-gold-soft" size={20} />
        <p className="text-sm font-medium text-ink">Login belum diaktifkan</p>
        <p className="mx-auto mt-1 max-w-sm text-xs text-ink-muted">
          Isi <code className="rounded bg-surface-hover px-1 py-0.5 text-gold-soft">VITE_SUPABASE_URL</code>,{' '}
          <code className="rounded bg-surface-hover px-1 py-0.5 text-gold-soft">VITE_SUPABASE_ANON_KEY</code>, dan{' '}
          <code className="rounded bg-surface-hover px-1 py-0.5 text-gold-soft">VITE_ADMIN_EMAIL</code> di file{' '}
          <code className="rounded bg-surface-hover px-1 py-0.5 text-gold-soft">.env</code> — langkah lengkapnya ada
          di <code className="rounded bg-surface-hover px-1 py-0.5 text-gold-soft">LOGIN_GALERI_SETUP.md</code>.
        </p>
      </SpotlightCard>
    )
  }

  if (isLoading) {
    return <div className="skeleton h-40 rounded-2xl" />
  }

  if (user) {
    return (
      <SpotlightCard className="flex flex-col items-center gap-3 p-6 text-center sm:flex-row sm:items-center sm:text-left">
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-gold to-violet text-sm font-semibold text-base">
          {initials(user.email ?? '') || <UserRound size={18} />}
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium text-ink">{user.email}</p>
          <p className="mt-0.5 inline-flex items-center gap-1 text-xs text-ink-muted">
            {isAdmin ? (
              <>
                <ShieldCheck size={13} className="text-gold-soft" /> Masuk sebagai admin
              </>
            ) : (
              'Masuk sebagai pengunjung'
            )}
          </p>
        </div>
        <button
          onClick={signOut}
          className="inline-flex shrink-0 items-center gap-1.5 rounded-xl border border-border px-3.5 py-2 text-xs font-medium text-ink-muted transition hover:border-red-500/40 hover:text-red-400"
        >
          <LogOut size={14} /> Keluar
        </button>
      </SpotlightCard>
    )
  }

  return (
    <SpotlightCard className="p-6">
      <div className="mb-4">
        <p className="text-sm font-medium text-ink">Masuk ke akun</p>
        <p className="mt-1 text-xs text-ink-muted">
          Login dipakai untuk fitur admin (menambahkan gambar ke galeri publik).
        </p>
      </div>
      <div className="flex flex-col gap-2.5">
        {PROVIDERS.map((provider) => (
          <SocialButton key={provider} social={provider} theme="brand" onClick={() => signInWithProvider(provider)} />
        ))}
      </div>
    </SpotlightCard>
  )
}
