import { useEffect, useRef, useState, type FormEvent } from 'react'
import { ImagePlus, Images, Sparkles, Trash2 } from 'lucide-react'
import { supabase, isSupabaseConfigured } from '@/lib/supabaseClient'
import { generateId } from '@/lib/format'
import type { GalleryImage } from '@/types'
import FadeInSection from '@/components/reactbits/FadeInSection'
import SpotlightCard from '@/components/reactbits/SpotlightCard'
import EmptyState from '@/components/ui/EmptyState'
import Button from '@/components/ui/Button'
import { useToast } from '@/context/ToastContext'
import { useAuth } from '@/context/AuthContext'

const TABLE = 'gallery_images'

/**
 * PublicGallery — galeri gambar publik (dari URL), tersinkron lewat Supabase
 * seperti "Komentar Pengunjung" (lihat GuestComments.tsx untuk pola yang sama:
 * load awal + Realtime INSERT/DELETE + optimistic UI saat menambah).
 *
 * Yang bisa melihat galeri: SEMUA pengunjung (publik), tanpa perlu login.
 * Yang bisa MENAMBAHKAN gambar lewat URL: HANYA akun admin (isAdmin dari
 * AuthContext, dicocokkan dengan VITE_ADMIN_EMAIL). Kalau bukan admin (belum
 * login, atau login tapi bukan akun admin), form tambah-gambar tidak dirender
 * sama sekali — bukan cuma disembunyikan/disabled, memang dihilangkan dari DOM.
 * Perlindungan sesungguhnya tetap di RLS policy tabel `gallery_images` di
 * Supabase (lihat LOGIN_GALERI_SETUP.md), bukan di kondisi render ini saja.
 */
export default function PublicGallery() {
  const { showToast } = useToast()
  const { isAdmin } = useAuth()
  const [images, setImages] = useState<GalleryImage[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [url, setUrl] = useState('')
  const knownIds = useRef<Set<string>>(new Set())

  useEffect(() => {
    if (!supabase) {
      setIsLoading(false)
      return
    }

    let isMounted = true

    async function loadImages() {
      const { data, error } = await supabase!
        .from(TABLE)
        .select('id, url, created_at')
        .order('created_at', { ascending: false })
        .limit(60)

      if (!isMounted) return
      if (error) {
        showToast('Gagal memuat galeri. Coba muat ulang halaman.', 'error')
      } else if (data) {
        setImages(data as GalleryImage[])
        data.forEach((img) => knownIds.current.add((img as GalleryImage).id))
      }
      setIsLoading(false)
    }

    loadImages()

    const channel = supabase
      .channel('public:gallery_images')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: TABLE }, (payload) => {
        const incoming = payload.new as GalleryImage
        if (knownIds.current.has(incoming.id)) return
        knownIds.current.add(incoming.id)
        setImages((prev) => [incoming, ...prev])
      })
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: TABLE }, (payload) => {
        const removedId = (payload.old as { id: string }).id
        knownIds.current.delete(removedId)
        setImages((prev) => prev.filter((img) => img.id !== removedId))
      })
      .subscribe()

    return () => {
      isMounted = false
      supabase?.removeChannel(channel)
    }
  }, [showToast])

  async function handleAdd(e: FormEvent) {
    e.preventDefault()
    if (!supabase) return

    const trimmedUrl = url.trim()
    if (!trimmedUrl) {
      showToast('Isi URL gambar dulu, ya.', 'error')
      return
    }
    try {
      new URL(trimmedUrl)
    } catch {
      showToast('URL gambar tidak valid.', 'error')
      return
    }

    setIsSubmitting(true)

    const optimisticId = generateId('local')
    const optimisticImage: GalleryImage = {
      id: optimisticId,
      url: trimmedUrl,
      created_at: new Date().toISOString(),
    }
    knownIds.current.add(optimisticId)
    setImages((prev) => [optimisticImage, ...prev])

    const { data, error } = await supabase
      .from(TABLE)
      .insert({ url: trimmedUrl })
      .select('id, url, created_at')
      .single()

    setIsSubmitting(false)

    if (error) {
      setImages((prev) => prev.filter((img) => img.id !== optimisticId))
      showToast('Gagal menambahkan gambar. Pastikan kamu login sebagai admin.', 'error')
      return
    }

    if (data) {
      const saved = data as GalleryImage
      knownIds.current.add(saved.id)
      setImages((prev) => prev.map((img) => (img.id === optimisticId ? saved : img)))
    }

    setUrl('')
    showToast('Gambar berhasil ditambahkan ke galeri.', 'success')
  }

  async function handleDelete(id: string) {
    if (!supabase) return
    const prev = images
    setImages((p) => p.filter((img) => img.id !== id))
    const { error } = await supabase.from(TABLE).delete().eq('id', id)
    if (error) {
      setImages(prev)
      showToast('Gagal menghapus gambar.', 'error')
    }
  }

  return (
    <FadeInSection className="mt-14">
      <div className="mb-6 flex items-center gap-2">
        <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-surface-hover text-gold-soft">
          <Images size={17} />
        </span>
        <div>
          <h2 className="font-display text-xl font-semibold text-ink">Galeri</h2>
          <p className="text-xs text-ink-muted">Kumpulan gambar publik — bisa dilihat semua orang.</p>
        </div>
      </div>

      {!isSupabaseConfigured ? (
        <SpotlightCard className="p-6 text-center">
          <Sparkles className="mx-auto mb-2 text-gold-soft" size={20} />
          <p className="text-sm font-medium text-ink">Galeri belum diaktifkan</p>
          <p className="mx-auto mt-1 max-w-sm text-xs text-ink-muted">
            Setup Supabase-nya sama seperti fitur komentar, tinggal tambah tabel{' '}
            <code className="rounded bg-surface-hover px-1 py-0.5 text-gold-soft">gallery_images</code> — lihat{' '}
            <code className="rounded bg-surface-hover px-1 py-0.5 text-gold-soft">LOGIN_GALERI_SETUP.md</code>.
          </p>
        </SpotlightCard>
      ) : (
        <>
          {/* Form tambah gambar dari URL — HANYA dirender kalau isAdmin true.
              Bukan admin (termasuk belum login) = elemen ini tidak ada sama sekali. */}
          {isAdmin && (
            <form onSubmit={handleAdd} className="mb-6 flex flex-col gap-2.5 sm:flex-row">
              <input
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://contoh.com/gambar.jpg"
                type="url"
                className="flex-1 rounded-xl border border-border bg-surface px-4 py-2.5 text-sm text-ink outline-none focus:border-gold/50"
              />
              <Button type="submit" size="md" isLoading={isSubmitting}>
                <ImagePlus size={16} /> Tambah Gambar
              </Button>
            </form>
          )}

          {isLoading && (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="skeleton aspect-square rounded-2xl" />
              ))}
            </div>
          )}

          {!isLoading && images.length === 0 && (
            <EmptyState icon={Images} title="Galeri masih kosong" description="Belum ada gambar yang ditambahkan." />
          )}

          {!isLoading && images.length > 0 && (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
              {images.map((img, index) => (
                <FadeInSection key={img.id} delay={Math.min(index, 6) * 50}>
                  <div className="group/img relative aspect-square overflow-hidden rounded-2xl border border-border-soft bg-surface">
                    <img
                      src={img.url}
                      alt=""
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-300 group-hover/img:scale-105"
                      onError={(e) => {
                        ;(e.currentTarget as HTMLImageElement).style.display = 'none'
                      }}
                    />
                    {isAdmin && (
                      <button
                        onClick={() => handleDelete(img.id)}
                        aria-label="Hapus gambar"
                        className="absolute right-2 top-2 flex h-8 w-8 items-center justify-center rounded-full bg-black/60 text-white opacity-0 backdrop-blur transition-opacity group-hover/img:opacity-100 hover:bg-red-500/80"
                      >
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>
                </FadeInSection>
              ))}
            </div>
          )}
        </>
      )}
    </FadeInSection>
  )
}
