import { useRef, type ChangeEvent } from 'react'
import { Camera, Loader2, User } from 'lucide-react'
import { useProfile } from '@/context/ProfileContext'
import { cn } from '@/lib/format'

interface Props {
  size?: 'sm' | 'md' | 'lg' | 'xl'
  editable?: boolean
  className?: string
}

const sizeClasses: Record<NonNullable<Props['size']>, string> = {
  sm: 'w-10 h-10 md:w-14 md:h-14',
  md: 'w-20 h-20',
  lg: 'w-32 h-32',
  xl: 'w-40 h-40 md:w-48 md:h-48',
}

/**
 * Foto profil pemilik portfolio. Mendukung unggah JPG, JPEG, PNG, dan GIF
 * (maks 12 MB) — GIF ditampilkan apa adanya lewat <img> sehingga animasinya
 * tetap berjalan (tidak dibekukan/dijadikan statis).
 */
export default function ProfilePhotoUpload({ size = 'lg', editable = true, className }: Props) {
  const { profile, setPhotoFile, isUploadingPhoto } = useProfile()
  const inputRef = useRef<HTMLInputElement>(null)

  function handleFileChange(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (file) void setPhotoFile(file)
    e.target.value = ''
  }

  return (
    <div className={cn('relative inline-flex shrink-0', className)}>
      <div
        className={cn(
          'overflow-hidden rounded-full border-[3px] border-white/50 bg-[#D2B48C] shadow-inner flex items-center justify-center',
          sizeClasses[size],
        )}
      >
        {profile.photo ? (
          <img src={profile.photo} alt={profile.name} className="h-full w-full object-cover" />
        ) : (
          <User className="h-1/2 w-1/2 text-white/70" />
        )}
      </div>

      {editable && (
        <>
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            disabled={isUploadingPhoto}
            aria-label="Ganti foto profil"
            className="absolute bottom-0 right-0 flex h-8 w-8 items-center justify-center rounded-full bg-gold text-base shadow-lg transition hover:brightness-110 disabled:opacity-60"
          >
            {isUploadingPhoto ? <Loader2 size={14} className="animate-spin" /> : <Camera size={14} />}
          </button>
          <input
            ref={inputRef}
            type="file"
            accept=".jpg,.jpeg,.png,.gif,image/jpeg,image/png,image/gif"
            onChange={handleFileChange}
            className="hidden"
          />
        </>
      )}
    </div>
  )
}
