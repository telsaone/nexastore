import { forwardRef, type ButtonHTMLAttributes } from 'react'
import { Loader2 } from 'lucide-react'
import { cn } from '@/lib/format'

export type SocialKind = 'google' | 'facebook' | 'apple'
type Theme = 'brand' | 'outline'

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  social: SocialKind
  theme?: Theme
  isLoading?: boolean
}

/**
 * SocialButton — tombol login sosial (Google/Facebook/Apple), gaya "Untitled UI"
 * tapi disesuaikan ke token desain proyek ini (bg-surface/border-border/text-ink,
 * bukan token shadcn) supaya menyatu dengan tema gelap/terang NexaStore.
 *
 * `theme="brand"` → latar warna khas tiap provider (putih untuk Google/Apple,
 * biru Facebook). `theme="outline"` (default) → netral, ikut warna kartu di
 * sekitarnya, cocok dipakai di tema gelap tanpa mencolok.
 */
const GoogleIcon = () => (
  <svg viewBox="0 0 24 24" className="h-[18px] w-[18px]" aria-hidden="true">
    <path
      fill="#4285F4"
      d="M23.52 12.27c0-.85-.08-1.67-.22-2.45H12v4.64h6.47a5.53 5.53 0 0 1-2.4 3.63v3h3.87c2.27-2.09 3.58-5.17 3.58-8.82Z"
    />
    <path
      fill="#34A853"
      d="M12 24c3.24 0 5.96-1.07 7.94-2.91l-3.87-3c-1.08.72-2.45 1.15-4.07 1.15-3.13 0-5.78-2.11-6.73-4.96H1.27v3.1A11.998 11.998 0 0 0 12 24Z"
    />
    <path
      fill="#FBBC05"
      d="M5.27 14.28A7.2 7.2 0 0 1 4.89 12c0-.79.14-1.56.38-2.28v-3.1H1.27A12 12 0 0 0 0 12c0 1.94.46 3.77 1.27 5.38l4-3.1Z"
    />
    <path
      fill="#EA4335"
      d="M12 4.77c1.76 0 3.34.6 4.59 1.79l3.44-3.44C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.69 1.27 6.62l4 3.1c.95-2.85 3.6-4.95 6.73-4.95Z"
    />
  </svg>
)

const FacebookIcon = ({ mono }: { mono?: boolean }) => (
  <svg viewBox="0 0 24 24" className="h-[18px] w-[18px]" aria-hidden="true">
    <path
      fill={mono ? 'currentColor' : '#1877F2'}
      d="M24 12.07C24 5.68 18.63.5 12 .5S0 5.68 0 12.07c0 5.77 4.39 10.56 10.13 11.43v-8.09H7.08v-3.34h3.05V9.41c0-2.99 1.8-4.64 4.55-4.64 1.32 0 2.7.23 2.7.23v2.94h-1.52c-1.5 0-1.96.92-1.96 1.86v2.23h3.34l-.53 3.34h-2.81v8.09C19.61 22.63 24 17.84 24 12.07Z"
    />
  </svg>
)

const AppleIcon = ({ light }: { light?: boolean }) => (
  <svg
    viewBox="0 0 24 24"
    className="h-[18px] w-[18px]"
    fill={light ? '#000000' : 'currentColor'}
    aria-hidden="true"
  >
    <path d="M16.36 1.44c0 1.14-.42 2.2-1.18 3.02-.86.93-2.06 1.63-3.24 1.53-.13-1.14.44-2.32 1.16-3.06.85-.9 2.28-1.58 3.26-1.49Zm3.53 16.6c-.44 1.02-.65 1.47-1.22 2.37-.79 1.25-1.9 2.81-3.28 2.83-1.23.02-1.55-.8-3.21-.79-1.67.01-2.02.8-3.25.78-1.38-.02-2.43-1.42-3.22-2.67-2.21-3.5-2.44-7.6-1.08-9.79.97-1.56 2.5-2.47 3.94-2.47 1.47 0 2.39.81 3.6.81 1.18 0 1.89-.81 3.6-.81 1.28 0 2.64.7 3.6 1.9-3.17 1.74-2.66 6.27.72 7.84Z" />
  </svg>
)

const LABEL: Record<SocialKind, string> = {
  google: 'Google',
  facebook: 'Facebook',
  apple: 'Apple',
}

const brandClasses: Record<SocialKind, string> = {
  google: 'bg-white text-[#1F1F1F] border border-border-soft hover:bg-white/90',
  facebook: 'bg-[#1877F2] text-white hover:brightness-110',
  apple: 'bg-black text-white hover:brightness-125',
}

const SocialButton = forwardRef<HTMLButtonElement, Props>(
  ({ social, theme = 'outline', isLoading, disabled, className, children, ...rest }, ref) => {
    const icon =
      social === 'google' ? (
        <GoogleIcon />
      ) : social === 'facebook' ? (
        <FacebookIcon mono={theme === 'outline'} />
      ) : (
        <AppleIcon light={theme === 'brand'} />
      )

    return (
      <button
        ref={ref}
        disabled={disabled || isLoading}
        className={cn(
          'inline-flex w-full items-center justify-center gap-2.5 rounded-xl px-4 py-2.5 text-sm font-medium transition-all duration-200 disabled:cursor-not-allowed disabled:opacity-50',
          theme === 'brand'
            ? brandClasses[social]
            : 'border border-border bg-surface text-ink hover:border-gold/40 hover:bg-surface-hover',
          className,
        )}
        {...rest}
      >
        {isLoading ? <Loader2 size={16} className="animate-spin" /> : icon}
        {children ?? `Lanjutkan dengan ${LABEL[social]}`}
      </button>
    )
  },
)

SocialButton.displayName = 'SocialButton'
export { SocialButton }
