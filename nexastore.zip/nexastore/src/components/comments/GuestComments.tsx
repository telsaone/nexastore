import { useEffect, useRef, useState } from 'react'
import { MessageCircle, Sparkles } from 'lucide-react'
import { supabase, isSupabaseConfigured } from '@/lib/supabaseClient'
import { avatarGradient, formatRelativeTime, generateId, initials } from '@/lib/format'
import type { GuestComment } from '@/types'
import FadeInSection from '@/components/reactbits/FadeInSection'
import SpotlightCard from '@/components/reactbits/SpotlightCard'
import { PromptInputBox } from '@/components/ui/ai-prompt-box'
import { useToast } from '@/context/ToastContext'

const TABLE = 'comments'
const MESSAGE_MAX = 500

/**
 * GuestComments — "dinding komentar" publik: semua pengunjung website bisa saling
 * melihat komentar satu sama lain (disimpan di Supabase, bukan cuma localStorage).
 *
 * - Live update: komentar baru dari pengunjung LAIN otomatis muncul tanpa refresh,
 *   lewat Supabase Realtime (subscribe ke event INSERT tabel `comments`).
 * - Optimistic UI: komentar milik kita sendiri langsung muncul begitu terkirim,
 *   tidak menunggu roundtrip realtime.
 * - Kalau kredensial Supabase belum diisi di .env, komponen ini menampilkan kartu
 *   "belum dikonfigurasi" yang rapi (bukan error merah) — lihat KOMENTAR_SETUP.md
 *   di root proyek untuk cara setup lengkap (skema tabel + RLS policy).
 */
export default function GuestComments() {
  const { showToast } = useToast()
  const [comments, setComments] = useState<GuestComment[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [name, setName] = useState('')
  const knownIds = useRef<Set<string>>(new Set())

  useEffect(() => {
    if (!supabase) {
      setIsLoading(false)
      return
    }

    let isMounted = true

    async function loadComments() {
      const { data, error } = await supabase!
        .from(TABLE)
        .select('id, name, message, created_at')
        .order('created_at', { ascending: false })
        .limit(100)

      if (!isMounted) return
      if (error) {
        showToast('Gagal memuat komentar. Coba muat ulang halaman.', 'error')
      } else if (data) {
        setComments(data as GuestComment[])
        data.forEach((c) => knownIds.current.add((c as GuestComment).id))
      }
      setIsLoading(false)
    }

    loadComments()

    // Live update — komentar baru dari pengunjung lain langsung nongol di sini.
    const channel = supabase
      .channel('public:comments')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: TABLE },
        (payload) => {
          const incoming = payload.new as GuestComment
          if (knownIds.current.has(incoming.id)) return
          knownIds.current.add(incoming.id)
          setComments((prev) => [incoming, ...prev])
        },
      )
      .subscribe()

    return () => {
      isMounted = false
      supabase?.removeChannel(channel)
    }
  }, [showToast])

  async function handleSend(rawMessage: string, _files?: File[]) {
    if (!supabase) return

    const trimmedName = name.trim()
    const trimmedMessage = rawMessage.trim().slice(0, MESSAGE_MAX)

    if (!trimmedName || !trimmedMessage) {
      showToast('Isi nama dan komentar dulu, ya.', 'error')
      return
    }

    setIsSubmitting(true)

    // Optimistic UI: tampilkan dulu di layar kita sebelum server konfirmasi.
    const optimisticId = generateId('local')
    const optimisticComment: GuestComment = {
      id: optimisticId,
      name: trimmedName,
      message: trimmedMessage,
      created_at: new Date().toISOString(),
    }
    knownIds.current.add(optimisticId)
    setComments((prev) => [optimisticComment, ...prev])

    const { data, error } = await supabase
      .from(TABLE)
      .insert({ name: trimmedName, message: trimmedMessage })
      .select('id, name, message, created_at')
      .single()

    setIsSubmitting(false)

    if (error) {
      // Gagal kirim — buang versi optimistic-nya lagi.
      setComments((prev) => prev.filter((c) => c.id !== optimisticId))
      showToast('Komentar gagal terkirim. Coba lagi sebentar lagi.', 'error')
      return
    }

    if (data) {
      const saved = data as GuestComment
      knownIds.current.add(saved.id)
      setComments((prev) => prev.map((c) => (c.id === optimisticId ? saved : c)))
    }

    showToast('Komentar kamu berhasil ditambahkan!', 'success')
  }

  return (
    <FadeInSection className="mt-14">
      <div className="mb-6 flex items-center gap-2">
        <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-surface-hover text-gold-soft">
          <MessageCircle size={17} />
        </span>
        <div>
          <h2 className="font-display text-xl font-semibold text-ink">Komentar Pengunjung</h2>
          <p className="text-xs text-ink-muted">Tinggalkan jejak — semua orang bisa lihat komentarmu di sini.</p>
        </div>
      </div>

      {!isSupabaseConfigured ? (
        <SpotlightCard className="p-6 text-center">
          <Sparkles className="mx-auto mb-2 text-gold-soft" size={20} />
          <p className="text-sm font-medium text-ink">Dinding komentar belum diaktifkan</p>
          <p className="mx-auto mt-1 max-w-sm text-xs text-ink-muted">
            Isi <code className="rounded bg-surface-hover px-1 py-0.5 text-gold-soft">VITE_SUPABASE_URL</code> dan{' '}
            <code className="rounded bg-surface-hover px-1 py-0.5 text-gold-soft">VITE_SUPABASE_ANON_KEY</code> di
            file <code className="rounded bg-surface-hover px-1 py-0.5 text-gold-soft">.env</code> — langkah
            lengkapnya ada di <code className="rounded bg-surface-hover px-1 py-0.5 text-gold-soft">KOMENTAR_SETUP.md</code>.
          </p>
        </SpotlightCard>
      ) : (
        <div className="grid grid-cols-1 gap-6 md:grid-cols-[1fr_1.2fr]">
          <div className="flex flex-col gap-3">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Nama kamu"
              maxLength={60}
              className="rounded-xl border border-border bg-surface px-4 py-2.5 text-sm text-ink outline-none focus:border-gold/50"
            />
            <PromptInputBox
              onSend={handleSend}
              isLoading={isSubmitting}
              placeholder="Tulis komentar untuk website ini..."
            />
          </div>

          <div className="flex max-h-[420px] flex-col gap-3 overflow-y-auto pr-1">
            {isLoading && (
              <>
                <div className="skeleton h-20 rounded-xl" />
                <div className="skeleton h-20 rounded-xl" />
              </>
            )}

            {!isLoading && comments.length === 0 && (
              <SpotlightCard className="p-5 text-center text-sm text-ink-muted">
                Belum ada komentar — jadilah yang pertama menyapa! 👋
              </SpotlightCard>
            )}

            {comments.map((comment, index) => (
              <FadeInSection key={comment.id} delay={Math.min(index, 5) * 60}>
                <SpotlightCard className="flex gap-3 p-4">
                  <span
                    className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br ${avatarGradient(
                      comment.name,
                    )} text-xs font-semibold text-base`}
                  >
                    {initials(comment.name) || '?'}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-baseline justify-between gap-2">
                      <p className="truncate text-sm font-medium text-ink">{comment.name}</p>
                      <span className="shrink-0 text-[10px] text-ink-faint">
                        {formatRelativeTime(comment.created_at)}
                      </span>
                    </div>
                    <p className="mt-0.5 whitespace-pre-wrap break-words text-sm text-ink-muted">
                      {comment.message}
                    </p>
                  </div>
                </SpotlightCard>
              </FadeInSection>
            ))}
          </div>
        </div>
      )}
    </FadeInSection>
  )
}
