import { ExternalLink, Github } from 'lucide-react'
import type { Project } from '@/types'
import { getCategoryLabel } from '@/data/projects'
import Badge from '@/components/ui/Badge'
import SpotlightCard from '@/components/reactbits/SpotlightCard'

export default function ProjectCard({ project }: { project: Project }) {
  return (
    <SpotlightCard className="flex h-full flex-col overflow-hidden p-0">
      <div className="aspect-[16/10] w-full overflow-hidden bg-surface-hover">
        <img
          src={project.coverImage}
          alt={project.title}
          className="h-full w-full object-cover transition duration-300 hover:scale-105"
          loading="lazy"
        />
      </div>
      <div className="flex flex-1 flex-col gap-2.5 p-4">
        <div className="flex items-center justify-between gap-2">
          <Badge tone="gold">{getCategoryLabel(project.category)}</Badge>
          <span className="text-xs text-ink-faint">{project.year}</span>
        </div>
        <h3 className="font-display text-base font-semibold text-ink">{project.title}</h3>
        <p className="text-sm text-ink-muted line-clamp-2">{project.description}</p>
        <div className="mt-auto flex flex-wrap gap-1.5 pt-1">
          {project.tags.map((tag) => (
            <span key={tag} className="rounded-md bg-surface-hover px-2 py-0.5 text-[11px] text-ink-muted">
              {tag}
            </span>
          ))}
        </div>
        {(project.link || project.repo) && (
          <div className="mt-2 flex items-center gap-3 border-t border-border-soft pt-3">
            {project.link && (
              <a
                href={project.link}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-gold-soft hover:text-gold"
              >
                <ExternalLink size={13} /> Lihat Demo
              </a>
            )}
            {project.repo && (
              <a
                href={project.repo}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-ink-muted hover:text-ink"
              >
                <Github size={13} /> Kode Sumber
              </a>
            )}
          </div>
        )}
      </div>
    </SpotlightCard>
  )
}
